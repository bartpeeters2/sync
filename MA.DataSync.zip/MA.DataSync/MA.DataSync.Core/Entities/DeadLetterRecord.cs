﻿using MA.DataSync.Core.Enums;

namespace MA.DataSync.Core.Entities;

/// <summary>
/// Represents a record that failed permanently and was sent to the Dead-Letter Queue.
/// Stored in BigQuery for investigation and potential manual retry.
/// </summary>
public class DeadLetterRecord
{
    /// <summary>
    /// Unique identifier for this DLQ entry.
    /// </summary>
    public string Id { get; set; } = Guid.NewGuid().ToString();

    /// <summary>
    /// The RunId when this failure occurred.
    /// </summary>
    public string RunId { get; set; } = string.Empty;

    /// <summary>
    /// The entity type that failed.
    /// </summary>
    public EntityType EntityType { get; set; }

    /// <summary>
    /// The operation that was attempted.
    /// </summary>
    public SyncOperation Operation { get; set; }

    /// <summary>
    /// The alternate key values for the failed record.
    /// </summary>
    public Dictionary<string, object> AlternateKeys { get; set; } = new();

    /// <summary>
    /// The full source data that failed to sync.
    /// </summary>
    public Dictionary<string, object?> SourceData { get; set; } = new();

    /// <summary>
    /// The error message from the final failure.
    /// </summary>
    public string ErrorMessage { get; set; } = string.Empty;

    /// <summary>
    /// The full exception details (type, stack trace).
    /// </summary>
    public string? ExceptionDetails { get; set; }

    /// <summary>
    /// Dataverse error code if available.
    /// </summary>
    public string? DataverseErrorCode { get; set; }

    /// <summary>
    /// Number of retry attempts before giving up.
    /// </summary>
    public int RetryAttempts { get; set; }

    /// <summary>
    /// When this record was sent to DLQ.
    /// </summary>
    public DateTime FailedAt { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// The batch ID where this failure occurred.
    /// </summary>
    public string? BatchId { get; set; }

    /// <summary>
    /// Has this DLQ record been manually resolved?
    /// </summary>
    public bool IsResolved { get; set; }

    /// <summary>
    /// Notes from manual investigation/resolution.
    /// </summary>
    public string? ResolutionNotes { get; set; }
}