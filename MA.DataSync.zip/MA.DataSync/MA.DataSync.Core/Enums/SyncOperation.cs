﻿namespace MA.DataSync.Core.Enums;

/// <summary>
/// Defines the type of operation to perform on a record in Dataverse.
/// </summary>
public enum SyncOperation
{
    /// <summary>
    /// Record does not exist in Dataverse - create it.
    /// </summary>
    Create,

    /// <summary>
    /// Record exists in Dataverse - update it.
    /// </summary>
    Update,

    /// <summary>
    /// Record marked as deleted in BigQuery - deactivate in Dataverse.
    /// </summary>
    Delete,

    /// <summary>
    /// No action needed - record unchanged or already processed.
    /// </summary>
    Skip
}
