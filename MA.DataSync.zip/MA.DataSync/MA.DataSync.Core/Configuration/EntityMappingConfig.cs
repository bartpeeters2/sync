﻿namespace MA.DataSync.Core.Configuration;

/// <summary>
/// Configuration for mapping a single entity between BigQuery and Dataverse.
/// </summary>
public class EntityMappingConfig
{
    /// <summary>
    /// BigQuery table name (e.g., "contact_latest").
    /// </summary>
    public string BigQueryTable { get; set; } = string.Empty;

    /// <summary>
    /// Dataverse entity logical name (e.g., "contact").
    /// </summary>
    public string DataverseTable { get; set; } = string.Empty;

    /// <summary>
    /// Column name in BigQuery for watermark filtering.
    /// </summary>
    public string ModifiedDateColumn { get; set; } = "modified_at";

    /// <summary>
    /// Column name in BigQuery for delete detection.
    /// </summary>
    public string DeleteFlagColumn { get; set; } = "is_deleted";

    /// <summary>
    /// Fields that form the alternate key in Dataverse.
    /// Used to check if record exists.
    /// </summary>
    public List<string> AlternateKeys { get; set; } = new();

    /// <summary>
    /// Field mappings from BigQuery column to Dataverse field.
    /// Key = BigQuery column name, Value = Dataverse field name.
    /// </summary>
    public Dictionary<string, string> FieldMappings { get; set; } = new();

    /// <summary>
    /// Lookup (relationship) mappings to other entities.
    /// </summary>
    public List<LookupMappingConfig> Lookups { get; set; } = new();
}

/// <summary>
/// Configuration for a lookup (relationship) field.
/// </summary>
public class LookupMappingConfig
{
    /// <summary>
    /// Column name in BigQuery containing the reference value.
    /// Example: "person_id"
    /// </summary>
    public string SourceColumn { get; set; } = string.Empty;

    /// <summary>
    /// Dataverse lookup field name.
    /// Example: "ma_physicalpersonid"
    /// </summary>
    public string TargetLookupField { get; set; } = string.Empty;

    /// <summary>
    /// The related entity's logical name in Dataverse.
    /// Example: "ma_physicalperson"
    /// </summary>
    public string TargetEntity { get; set; } = string.Empty;

    /// <summary>
    /// The field in the target entity to match against.
    /// Example: "ma_email" (alternate key of target entity)
    /// </summary>
    public string TargetMatchField { get; set; } = string.Empty;
}

/// <summary>
/// Container for all entity mappings.
/// Maps to "EntityMappings" section in appsettings.json.
/// </summary>
public class EntityMappingsConfig
{
    /// <summary>
    /// Mapping configuration for PhysicalPerson entity.
    /// </summary>
    public EntityMappingConfig PhysicalPerson { get; set; } = new();

    /// <summary>
    /// Mapping configuration for Contact entity.
    /// </summary>
    public EntityMappingConfig Contact { get; set; } = new();

    /// <summary>
    /// Mapping configuration for Account entity.
    /// </summary>
    public EntityMappingConfig Account { get; set; } = new();
}
