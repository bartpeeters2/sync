﻿using Google.Cloud.BigQuery.V2;
using Google.Apis.Auth.OAuth2;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MA.DataSync.Core.Configuration;
using MA.DataSync.Core.Entities;
using MA.DataSync.Core.Enums;
using MA.DataSync.Core.Interfaces;
using System.Collections.Generic;

namespace MA.DataSync.Infrastructure.BigQuery;

/// <summary>
/// Extracts records from BigQuery for synchronization.
/// </summary>
public class BigQueryExtractor : IBigQueryExtractor
{
    private readonly BigQueryClient _client;
    private readonly BigQuerySettings _settings;
    private readonly EntityMappingsConfig _mappings;
    private readonly ILogger<BigQueryExtractor> _logger;

    public BigQueryExtractor(
        IOptions<BigQuerySettings> settings,
        IOptions<EntityMappingsConfig> mappings,
        ILogger<BigQueryExtractor> logger)
    {
        _settings = settings.Value;
        _mappings = mappings.Value;
        _logger = logger;
        _client = CreateClient();
    }

    private BigQueryClient CreateClient()
    {
        if (!string.IsNullOrEmpty(_settings.ServiceAccountKeyPath))
        {
            _logger.LogInformation("Using service account key from: {Path}", _settings.ServiceAccountKeyPath);
            var credential = GoogleCredential.FromFile(_settings.ServiceAccountKeyPath);
            return BigQueryClient.Create(_settings.ProjectId, credential);
        }

        _logger.LogInformation("Using default credentials (Workload Identity)");
        return BigQueryClient.Create(_settings.ProjectId);
    }

    public async IAsyncEnumerable<SyncRecord> ExtractDeltaAsync(
    EntityType entityType,
    DateTime watermark,
    [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        var mapping = GetMapping(entityType);

        if (string.IsNullOrEmpty(mapping.BigQueryTable))
        {
            _logger.LogWarning("No BigQuery table configured for {EntityType}", entityType);
            yield break;
        }

        var sql = BuildQuery(mapping);
        _logger.LogInformation("Executing query for {EntityType}: {Sql}", entityType, sql);

        var parameters = new List<BigQueryParameter>();
        if (!string.IsNullOrEmpty(mapping.ModifiedDateColumn))
        {
            // Ensure DateTime is UTC for BigQuery
            var utcWatermark = DateTime.SpecifyKind(watermark, DateTimeKind.Utc);
            parameters.Add(new BigQueryParameter("watermark", BigQueryDbType.Timestamp, utcWatermark));
        }

        var results = await _client.ExecuteQueryAsync(sql, parameters, cancellationToken: cancellationToken);

        foreach (var row in results)
        {
            if (cancellationToken.IsCancellationRequested)
                yield break;

            yield return MapRowToSyncRecord(row, entityType, mapping);
        }
    }

    public async Task<DateTime?> GetMaxModifiedDateAsync(
        EntityType entityType,
        CancellationToken cancellationToken = default)
    {
        var mapping = GetMapping(entityType);

        if (string.IsNullOrEmpty(mapping.ModifiedDateColumn))
        {
            _logger.LogDebug("No ModifiedDateColumn configured for {EntityType}", entityType);
            return null;
        }

        var sql = $@"
            SELECT MAX({mapping.ModifiedDateColumn}) as max_date
            FROM `{_settings.ProjectId}.{_settings.DatasetId}.{mapping.BigQueryTable}`";

        var results = await _client.ExecuteQueryAsync(sql, parameters: null, cancellationToken: cancellationToken);
        var row = results.FirstOrDefault();

        if (row == null || row["max_date"] == null)
            return null;

        return row["max_date"] switch
        {
            DateTime dt => dt,
            DateTimeOffset dto => dto.UtcDateTime,
            _ => null
        };
    }

    public async Task<long> GetDeltaCountAsync(
       EntityType entityType,
       DateTime watermark,
       CancellationToken cancellationToken = default)
    {
        var mapping = GetMapping(entityType);

        if (string.IsNullOrEmpty(mapping.BigQueryTable))
            return 0;

        var sql = BuildCountQuery(mapping);
        _logger.LogDebug("Executing count query for {EntityType}: {Sql}", entityType, sql);

        var parameters = new List<BigQueryParameter>();
        if (!string.IsNullOrEmpty(mapping.ModifiedDateColumn))
        {
            // Ensure DateTime is UTC for BigQuery
            var utcWatermark = DateTime.SpecifyKind(watermark, DateTimeKind.Utc);
            parameters.Add(new BigQueryParameter("watermark", BigQueryDbType.Timestamp, utcWatermark));
        }

        var results = await _client.ExecuteQueryAsync(sql, parameters, cancellationToken: cancellationToken);
        var row = results.FirstOrDefault();

        return row?["count"] switch
        {
            long l => l,
            int i => i,
            _ => 0
        };
    }

    private EntityMappingConfig GetMapping(EntityType entityType)
    {
        return entityType switch
        {
            EntityType.PhysicalPerson => _mappings.PhysicalPerson,
            EntityType.Contact => _mappings.Contact,
            EntityType.Account => _mappings.Account,
            _ => throw new ArgumentOutOfRangeException(nameof(entityType))
        };
    }

    private string BuildQuery(EntityMappingConfig mapping)
    {
        var table = $"`{_settings.ProjectId}.{_settings.DatasetId}.{mapping.BigQueryTable}`";

        // Build explicit column list instead of SELECT *
        var columns = mapping.FieldMappings.Keys.ToList();

        // Add system columns if they exist
        if (!string.IsNullOrEmpty(mapping.ModifiedDateColumn) && !columns.Contains(mapping.ModifiedDateColumn))
            columns.Add(mapping.ModifiedDateColumn);

        if (!string.IsNullOrEmpty(mapping.DeleteFlagColumn) && !columns.Contains(mapping.DeleteFlagColumn))
            columns.Add(mapping.DeleteFlagColumn);

        var columnList = columns.Count > 0
            ? string.Join(", ", columns)
            : "*"; // Fallback if no mappings defined

        // If no watermark column, select all
        if (string.IsNullOrEmpty(mapping.ModifiedDateColumn))
        {
            return $"SELECT {columnList} FROM {table} LIMIT 10000";// TEMPORARY LIMIT
        }

        // With watermark filtering - use parameter placeholder
        return $@"
        SELECT {columnList} FROM {table}
        WHERE {mapping.ModifiedDateColumn} > @watermark
        ORDER BY {mapping.ModifiedDateColumn}
        LIMIT 10000";  // TEMPORARY LIMIT
    }

    private string BuildCountQuery(EntityMappingConfig mapping)
    {
        var table = $"`{_settings.ProjectId}.{_settings.DatasetId}.{mapping.BigQueryTable}`";

        if (string.IsNullOrEmpty(mapping.ModifiedDateColumn))
        {
            return $"SELECT COUNT(*) as count FROM {table} LIMIT 10000";// TEMPORARY LIMIT
        }

        return $@"
        SELECT COUNT(*) as count FROM {table}
        WHERE {mapping.ModifiedDateColumn} > @watermark";
    }

    private SyncRecord MapRowToSyncRecord(BigQueryRow row, EntityType entityType, EntityMappingConfig mapping)
    {
        var record = new SyncRecord
        {
            EntityType = entityType,
            Status = SyncStatus.Pending,
            Operation = SyncOperation.Skip
        };

        // Copy all fields from BigQuery row to SourceData
        foreach (var field in row.Schema.Fields)
        {
            record.SourceData[field.Name] = row[field.Name];
        }

        // Check if deleted (if column exists)
        if (!string.IsNullOrEmpty(mapping.DeleteFlagColumn) &&
            record.SourceData.TryGetValue(mapping.DeleteFlagColumn, out var deletedValue))
        {
            record.IsDeleted = deletedValue switch
            {
                bool b => b,
                long l => l == 1,
                int i => i == 1,
                string s => s.Equals("true", StringComparison.OrdinalIgnoreCase),
                _ => false
            };
        }

        // Get modified date (if column exists)
        if (!string.IsNullOrEmpty(mapping.ModifiedDateColumn) &&
            record.SourceData.TryGetValue(mapping.ModifiedDateColumn, out var modifiedValue))
        {
            record.SourceModifiedDate = modifiedValue switch
            {
                DateTime dt => dt,
                DateTimeOffset dto => dto.UtcDateTime,
                _ => DateTime.UtcNow
            };
        }

        return record;
    }
}