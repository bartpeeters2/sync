﻿using MA.DataSync.Core.Enums;

namespace MA.DataSync.Core.Interfaces;

/// <summary>
/// Manages checkpoints for resumable sync operations.
/// Stores progress in BigQuery so jobs can resume after failure.
/// </summary>
public interface ICheckpointRepository
{
    /// <summary>
    /// Gets the last successful watermark for an entity.
    /// This is where the next sync should start from.
    /// </summary>
    /// <param name="entityType">The entity type.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The watermark date, or null if never synced.</returns>
    Task<DateTime?> GetWatermarkAsync(
        EntityType entityType,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Updates the watermark after successful sync.
    /// </summary>
    /// <param name="entityType">The entity type.</param>
    /// <param name="watermark">The new watermark date.</param>
    /// <param name="runId">The run that completed this sync.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    Task SetWatermarkAsync(
        EntityType entityType,
        DateTime watermark,
        string runId,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Saves a checkpoint for the current run progress.
    /// Called periodically to enable resume after failure.
    /// </summary>
    /// <param name="checkpoint">The checkpoint data.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    Task SaveCheckpointAsync(
        SyncCheckpoint checkpoint,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets the latest incomplete checkpoint (if any).
    /// Used to resume a failed run.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The checkpoint to resume from, or null if no incomplete run.</returns>
    Task<SyncCheckpoint?> GetIncompleteCheckpointAsync(
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Marks a run as complete (successful or failed).
    /// </summary>
    /// <param name="runId">The run ID.</param>
    /// <param name="success">Whether the run succeeded.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    Task CompleteRunAsync(
        string runId,
        bool success,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Tries to acquire a lock for running the sync.
    /// Prevents overlapping runs.
    /// </summary>
    /// <param name="runId">The run ID trying to acquire lock.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>True if lock acquired, false if another run is active.</returns>
    Task<bool> TryAcquireLockAsync(
        string runId,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Releases the run lock.
    /// </summary>
    /// <param name="runId">The run ID releasing the lock.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    Task ReleaseLockAsync(
        string runId,
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Represents a point-in-time checkpoint for resumable syncs.
/// </summary>
public class SyncCheckpoint
{
    /// <summary>
    /// The run ID this checkpoint belongs to.
    /// </summary>
    public string RunId { get; set; } = string.Empty;

    /// <summary>
    /// When this checkpoint was created.
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// The entity currently being processed.
    /// </summary>
    public EntityType CurrentEntity { get; set; }

    /// <summary>
    /// The last successfully processed batch ID.
    /// </summary>
    public string? LastCompletedBatchId { get; set; }

    /// <summary>
    /// The watermark being used for current extraction.
    /// </summary>
    public DateTime CurrentWatermark { get; set; }

    /// <summary>
    /// Number of records processed so far for current entity.
    /// </summary>
    public int RecordsProcessed { get; set; }

    /// <summary>
    /// Is this run complete?
    /// </summary>
    public bool IsComplete { get; set; }

    /// <summary>
    /// Did this run succeed? (only valid if IsComplete = true)
    /// </summary>
    public bool? Success { get; set; }
}
