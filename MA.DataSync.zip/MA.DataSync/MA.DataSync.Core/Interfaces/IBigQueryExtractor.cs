﻿using MA.DataSync.Core.Entities;
using MA.DataSync.Core.Enums;

namespace MA.DataSync.Core.Interfaces;

/// <summary>
/// Extracts delta records from BigQuery for synchronization.
/// </summary>
public interface IBigQueryExtractor
{
    /// <summary>
    /// Extracts records that have changed since the last watermark.
    /// </summary>
    /// <param name="entityType">The entity type to extract.</param>
    /// <param name="watermark">Only extract records modified after this date.</param>
    /// <param name="cancellationToken">Cancellation token for graceful shutdown.</param>
    /// <returns>Async stream of records for memory-efficient processing.</returns>
    IAsyncEnumerable<SyncRecord> ExtractDeltaAsync(
        EntityType entityType,
        DateTime watermark,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets the current maximum modified date for an entity.
    /// Used to set the new watermark after successful sync.
    /// </summary>
    /// <param name="entityType">The entity type to check.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The maximum modified date, or null if no records exist.</returns>
    Task<DateTime?> GetMaxModifiedDateAsync(
        EntityType entityType,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets the count of records to be extracted (for progress reporting).
    /// </summary>
    /// <param name="entityType">The entity type to count.</param>
    /// <param name="watermark">Only count records modified after this date.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The number of records to extract.</returns>
    Task<long> GetDeltaCountAsync(
        EntityType entityType,
        DateTime watermark,
        CancellationToken cancellationToken = default);
}