﻿using MA.DataSync.Core.Enums;


namespace MA.DataSync.Core.Entities;

/// <summary>
/// Represents a single record to be synced from BigQuery to Dataverse.
/// </summary>
public class SyncRecord
{
    /// <summary>
    /// Unique identifier for this sync record (for tracking/logging).
    /// </summary>
    public string Id { get; set; } = Guid.NewGuid().ToString();

    /// <summary>
    /// The type of entity (PhysicalPerson, Contact, Account).
    /// </summary>
    public EntityType EntityType { get; set; }

    /// <summary>
    /// The alternate key value(s) used to identify this record in Dataverse.
    /// For now, this could be email. Later, composite keys.
    /// </summary>
    public Dictionary<string, object> AlternateKeys { get; set; } = new();

    /// <summary>
    /// All field values from BigQuery to sync to Dataverse.
    /// Key = field name, Value = field value.
    /// </summary>
    public Dictionary<string, object?> SourceData { get; set; } = new();

    /// <summary>
    /// The operation to perform (Create, Update, Delete, Skip).
    /// Determined after checking if record exists in Dataverse.
    /// </summary>
    public SyncOperation Operation { get; set; } = SyncOperation.Skip;

    /// <summary>
    /// Current status of this record in the sync process.
    /// </summary>
    public SyncStatus Status { get; set; } = SyncStatus.Pending;

    /// <summary>
    /// Is this record marked as deleted in BigQuery?
    /// </summary>
    public bool IsDeleted { get; set; }

    /// <summary>
    /// The last modified timestamp from BigQuery.
    /// Used for watermark tracking.
    /// </summary>
    public DateTime SourceModifiedDate { get; set; }

    /// <summary>
    /// Dataverse record ID (GUID) if the record already exists.
    /// Null if this is a new record.
    /// </summary>
    public Guid? DataverseId { get; set; }

    /// <summary>
    /// Number of times we've attempted to sync this record.
    /// </summary>
    public int RetryCount { get; set; }

    /// <summary>
    /// Error message if sync failed.
    /// </summary>
    public string? ErrorMessage { get; set; }
}

                  
