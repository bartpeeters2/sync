﻿using MA.DataSync.Core.Enums;


namespace MA.DataSync.Core.Entities;

/// <summary>
/// Represents a batch of records to be processed together.
/// Batches are sent to Dataverse in a single ExecuteMultiple request.
/// </summary>
public class SyncBatch
{
    /// <summary>
    /// Unique identifier for this batch (for tracking/logging).
    /// </summary>
    public string BatchId { get; set; } = Guid.NewGuid().ToString();

    /// <summary>
    /// The entity type for all records in this batch.
    /// A batch never mixes entity types.
    /// </summary>
    public EntityType EntityType { get; set; }

    /// <summary>
    /// The operation type for all records in this batch.
    /// A batch never mixes operations (all creates OR all updates).
    /// </summary>
    public SyncOperation Operation { get; set; }

    /// <summary>
    /// The records in this batch.
    /// </summary>
    public List<SyncRecord> Records { get; set; } = new();

    /// <summary>
    /// When this batch was created.
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// When this batch started processing.
    /// </summary>
    public DateTime? ProcessingStartedAt { get; set; }

    /// <summary>
    /// When this batch finished processing.
    /// </summary>
    public DateTime? ProcessingCompletedAt { get; set; }

    /// <summary>
    /// Number of records that succeeded.
    /// </summary>
    public int SuccessCount => Records.Count(r => r.Status == SyncStatus.Success);

    /// <summary>
    /// Number of records that failed.
    /// </summary>
    public int FailureCount => Records.Count(r =>
        r.Status == SyncStatus.TransientFailure ||
        r.Status == SyncStatus.PermanentFailure);

    /// <summary>
    /// Total processing time in milliseconds.
    /// </summary>
    public double? ProcessingTimeMs => ProcessingCompletedAt.HasValue && ProcessingStartedAt.HasValue
        ? (ProcessingCompletedAt.Value - ProcessingStartedAt.Value).TotalMilliseconds
        : null;
}
