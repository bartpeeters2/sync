﻿namespace MA.DataSync.Core.Configuration;

/// <summary>
/// Settings for Service Principal multiplexing.
/// Maps to "ServicePrincipals" section in appsettings.json.
/// </summary>
public class ServicePrincipalSettings
{
    /// <summary>
    /// Maximum number of Service Principals to use for parallel connections.
    /// Start with 1, scale up to 3 for higher throughput.
    /// </summary>
    public int MaxServicePrincipals { get; set; } = 1;

    /// <summary>
    /// Prefix for secret names in Google Secret Manager.
    /// Example: "dataverse-sp" results in "dataverse-sp1-client-id", etc.
    /// </summary>
    public string SecretNamePrefix { get; set; } = "dataverse-sp";
}

/// <summary>
/// Single Service Principal credentials for local development.
/// Maps to "ServicePrincipal" section in appsettings.Development.json.
/// In production, these come from Secret Manager instead.
/// </summary>
public class LocalServicePrincipalSettings
{
    /// <summary>
    /// Azure AD Tenant ID.
    /// </summary>
    public string TenantId { get; set; } = string.Empty;

    /// <summary>
    /// Application (Client) ID.
    /// </summary>
    public string ClientId { get; set; } = string.Empty;

    /// <summary>
    /// Client Secret.
    /// </summary>
    public string ClientSecret { get; set; } = string.Empty;
}