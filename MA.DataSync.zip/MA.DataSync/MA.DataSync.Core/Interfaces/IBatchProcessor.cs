﻿using MA.DataSync.Core.Entities;
using MA.DataSync.Core.Enums;

namespace MA.DataSync.Core.Interfaces;

/// <summary>
/// Processes records in batches with parallel execution and throttling.
/// </summary>
public interface IBatchProcessor
{
    /// <summary>
    /// Processes a collection of records in batches.
    /// Handles existence checking, create/update routing, and parallel execution.
    /// </summary>
    /// <param name="entityType">The entity type being processed.</param>
    /// <param name="records">Records to process.</param>
    /// <param name="context">The current sync run context.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>Processing results for all records.</returns>
    Task<BatchProcessingResult> ProcessAsync(
        EntityType entityType,
        IEnumerable<SyncRecord> records,
        SyncRunContext context,
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Result of batch processing.
/// </summary>
public class BatchProcessingResult
{
    /// <summary>
    /// Total records processed.
    /// </summary>
    public int TotalProcessed { get; set; }

    /// <summary>
    /// Records successfully synced.
    /// </summary>
    public int Succeeded { get; set; }

    /// <summary>
    /// Records that failed.
    /// </summary>
    public int Failed { get; set; }

    /// <summary>
    /// Records created in Dataverse.
    /// </summary>
    public int Created { get; set; }

    /// <summary>
    /// Records updated in Dataverse.
    /// </summary>
    public int Updated { get; set; }

    /// <summary>
    /// Records deactivated (soft deleted) in Dataverse.
    /// </summary>
    public int Deleted { get; set; }

    /// <summary>
    /// Records skipped (no action needed).
    /// </summary>
    public int Skipped { get; set; }

    /// <summary>
    /// Records sent to Dead-Letter Queue.
    /// </summary>
    public int SentToDlq { get; set; }

    /// <summary>
    /// Total processing time in milliseconds.
    /// </summary>
    public long ProcessingTimeMs { get; set; }

    /// <summary>
    /// Records that failed and need to go to DLQ.
    /// </summary>
    public List<SyncRecord> FailedRecords { get; set; } = new();
}