﻿using Google.Cloud.BigQuery.V2;
using Google.Apis.Auth.OAuth2;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MA.DataSync.Core.Configuration;
using MA.DataSync.Core.Enums;
using MA.DataSync.Core.Interfaces;

namespace MA.DataSync.Infrastructure.BigQuery;

/// <summary>
/// Manages checkpoints in BigQuery for resumable sync operations.
/// </summary>
public class CheckpointRepository : ICheckpointRepository
{
    private readonly BigQueryClient _client;
    private readonly BigQuerySettings _settings;
    private readonly ILogger<CheckpointRepository> _logger;

    private const string CheckpointTableName = "sync_checkpoint";
    private const string LockTableName = "sync_run_lock";

    private bool _tablesVerified = false;

    public CheckpointRepository(
        IOptions<BigQuerySettings> settings,
        ILogger<CheckpointRepository> logger)
    {
        _settings = settings.Value;
        _logger = logger;
        _client = CreateClient();
    }

    private BigQueryClient CreateClient()
    {
        if (!string.IsNullOrEmpty(_settings.ServiceAccountKeyPath))
        {
            var credential = GoogleCredential.FromFile(_settings.ServiceAccountKeyPath);
            return BigQueryClient.Create(_settings.ProjectId, credential);
        }

        return BigQueryClient.Create(_settings.ProjectId);
    }

    /// <summary>
    /// Ensures the checkpoint and lock tables exist.
    /// </summary>
    private async Task EnsureTablesExistAsync(CancellationToken cancellationToken)
    {
        if (_tablesVerified) return;

        await CreateCheckpointTableIfNotExistsAsync(cancellationToken);
        await CreateLockTableIfNotExistsAsync(cancellationToken);

        _tablesVerified = true;
    }

    private async Task CreateCheckpointTableIfNotExistsAsync(CancellationToken cancellationToken)
    {
        var tableId = $"{_settings.ProjectId}.{_settings.DatasetId}.{CheckpointTableName}";

        var sql = $@"
            CREATE TABLE IF NOT EXISTS `{tableId}` (
                entity_type STRING NOT NULL,
                last_watermark TIMESTAMP NOT NULL,
                run_id STRING NOT NULL,
                updated_at TIMESTAMP NOT NULL
            )";

        try
        {
            await _client.ExecuteQueryAsync(sql, parameters: null, cancellationToken: cancellationToken);
            _logger.LogDebug("Checkpoint table verified: {Table}", tableId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create checkpoint table");
            throw;
        }
    }

    private async Task CreateLockTableIfNotExistsAsync(CancellationToken cancellationToken)
    {
        var tableId = $"{_settings.ProjectId}.{_settings.DatasetId}.{LockTableName}";

        var sql = $@"
            CREATE TABLE IF NOT EXISTS `{tableId}` (
                lock_id STRING NOT NULL,
                run_id STRING NOT NULL,
                locked_at TIMESTAMP NOT NULL,
                expires_at TIMESTAMP NOT NULL
            )";

        try
        {
            await _client.ExecuteQueryAsync(sql, parameters: null, cancellationToken: cancellationToken);
            _logger.LogDebug("Lock table verified: {Table}", tableId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create lock table");
            throw;
        }
    }

    public async Task<DateTime?> GetWatermarkAsync(
        EntityType entityType,
        CancellationToken cancellationToken = default)
    {
        await EnsureTablesExistAsync(cancellationToken);

        var tableId = $"`{_settings.ProjectId}.{_settings.DatasetId}.{CheckpointTableName}`";
        var entityName = entityType.ToString();

        var sql = $@"
            SELECT last_watermark 
            FROM {tableId}
            WHERE entity_type = @entityType
            ORDER BY updated_at DESC
            LIMIT 1";

        var parameters = new[]
        {
            new BigQueryParameter("entityType", BigQueryDbType.String, entityName)
        };

        var results = await _client.ExecuteQueryAsync(sql, parameters, cancellationToken: cancellationToken);
        var row = results.FirstOrDefault();

        if (row == null)
        {
            _logger.LogDebug("No watermark found for {EntityType}", entityType);
            return null;
        }

        var watermark = row["last_watermark"] switch
        {
            DateTime dt => dt,
            DateTimeOffset dto => dto.UtcDateTime,
            _ => (DateTime?)null
        };

        _logger.LogDebug("Found watermark for {EntityType}: {Watermark}", entityType, watermark);
        return watermark;
    }

    public async Task SetWatermarkAsync(
        EntityType entityType,
        DateTime watermark,
        string runId,
        CancellationToken cancellationToken = default)
    {
        await EnsureTablesExistAsync(cancellationToken);

        var tableId = $"`{_settings.ProjectId}.{_settings.DatasetId}.{CheckpointTableName}`";
        var entityName = entityType.ToString();

        // Use MERGE to upsert
        var sql = $@"
            MERGE {tableId} AS target
            USING (SELECT @entityType as entity_type) AS source
            ON target.entity_type = source.entity_type
            WHEN MATCHED THEN
                UPDATE SET 
                    last_watermark = @watermark,
                    run_id = @runId,
                    updated_at = CURRENT_TIMESTAMP()
            WHEN NOT MATCHED THEN
                INSERT (entity_type, last_watermark, run_id, updated_at)
                VALUES (@entityType, @watermark, @runId, CURRENT_TIMESTAMP())";

        // Ensure DateTime is UTC for BigQuery
        var utcWatermark = DateTime.SpecifyKind(watermark, DateTimeKind.Utc);

        var parameters = new[]
        {
            new BigQueryParameter("entityType", BigQueryDbType.String, entityName),
            new BigQueryParameter("watermark", BigQueryDbType.Timestamp, utcWatermark),
            new BigQueryParameter("runId", BigQueryDbType.String, runId)
        };

        await _client.ExecuteQueryAsync(sql, parameters, cancellationToken: cancellationToken);
        _logger.LogInformation("Updated watermark for {EntityType}: {Watermark}", entityType, watermark);
    }

    public async Task SaveCheckpointAsync(
        SyncCheckpoint checkpoint,
        CancellationToken cancellationToken = default)
    {
        // For now, we just update the watermark
        // Later we can add more detailed checkpoint info
        await SetWatermarkAsync(
            checkpoint.CurrentEntity,
            checkpoint.CurrentWatermark,
            checkpoint.RunId,
            cancellationToken);
    }

    public async Task<SyncCheckpoint?> GetIncompleteCheckpointAsync(
        CancellationToken cancellationToken = default)
    {
        await EnsureTablesExistAsync(cancellationToken);

        // For now, return null - we'll implement full checkpoint resume later
        // This would check for runs that started but didn't complete
        _logger.LogDebug("Checking for incomplete checkpoints...");

        return null;
    }

    public async Task CompleteRunAsync(string runId, bool success, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Run {RunId} completed. Success: {Success}", runId, success);

        // Release lock when run completes
       // await ReleaseLockAsync(runId, cancellationToken);
    }

    public async Task<bool> TryAcquireLockAsync(string runId, CancellationToken cancellationToken = default)
    {
        await EnsureTablesExistAsync(cancellationToken);

        var tableId = $"`{_settings.ProjectId}.{_settings.DatasetId}.{LockTableName}`";
        var lockId = "sync_lock";
        var expiresAt = DateTime.UtcNow.AddHours(4); // Lock expires after 4 hours

        try
        {
            // First, clean up expired locks
            var cleanupSql = $@"
                DELETE FROM {tableId}
                WHERE lock_id = @lockId AND expires_at < CURRENT_TIMESTAMP()";

            await _client.ExecuteQueryAsync(cleanupSql,
                new[] { new BigQueryParameter("lockId", BigQueryDbType.String, lockId) },
                cancellationToken: cancellationToken);

            // Check if lock exists
            var checkSql = $@"
                SELECT run_id, expires_at 
                FROM {tableId}
                WHERE lock_id = @lockId
                LIMIT 1";

            var checkResult = await _client.ExecuteQueryAsync(checkSql,
                new[] { new BigQueryParameter("lockId", BigQueryDbType.String, lockId) },
                cancellationToken: cancellationToken);

            var existingLock = checkResult.FirstOrDefault();

            if (existingLock != null)
            {
                var existingRunId = existingLock["run_id"]?.ToString();
                _logger.LogWarning("Lock already held by run {ExistingRunId}", existingRunId);
                return false;
            }

            // Acquire lock
            var insertSql = $@"
                INSERT INTO {tableId} (lock_id, run_id, locked_at, expires_at)
                VALUES (@lockId, @runId, CURRENT_TIMESTAMP(), @expiresAt)";

            var parameters = new[]
            {
                new BigQueryParameter("lockId", BigQueryDbType.String, lockId),
                new BigQueryParameter("runId", BigQueryDbType.String, runId),
                new BigQueryParameter("expiresAt", BigQueryDbType.Timestamp, expiresAt)
            };

            await _client.ExecuteQueryAsync(insertSql, parameters, cancellationToken: cancellationToken);
            _logger.LogInformation("Acquired lock for run {RunId}", runId);

            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to acquire lock for run {RunId}", runId);
            return false;
        }
    }

    public async Task ReleaseLockAsync(string runId, CancellationToken cancellationToken = default)
    {
        await EnsureTablesExistAsync(cancellationToken);

        var tableId = $"`{_settings.ProjectId}.{_settings.DatasetId}.{LockTableName}`";
        var lockId = "sync_lock";

        var sql = $@"
            DELETE FROM {tableId}
            WHERE lock_id = @lockId AND run_id = @runId";

        var parameters = new[]
        {
            new BigQueryParameter("lockId", BigQueryDbType.String, lockId),
            new BigQueryParameter("runId", BigQueryDbType.String, runId)
        };

        await _client.ExecuteQueryAsync(sql, parameters, cancellationToken: cancellationToken);
        _logger.LogInformation("Released lock for run {RunId}", runId);
    }
}