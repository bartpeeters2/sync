﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using MA.DataSync.Core.Configuration;
using MA.DataSync.Core.Entities;
using MA.DataSync.Core.Enums;
using MA.DataSync.Core.Interfaces;
using Polly;
using Polly.Retry;

namespace MA.DataSync.Infrastructure.Dataverse;

/// <summary>
/// Client for interacting with Microsoft Dataverse.
/// Uses CreateMultipleRequest/UpdateMultipleRequest for bulk operations.
/// </summary>
public class DataverseClient : IDataverseClient, IDisposable
{
    // Dataverse transient error codes
    // See: https://learn.microsoft.com/en-us/power-apps/developer/data-platform/api-limits
    private const int ERROR_REQUESTS_EXCEEDED = -2147015902;       // 0x80072322 - Number of requests exceeded
    private const int ERROR_EXECUTION_TIME_EXCEEDED = -2147015903; // 0x80072321 - Combined execution time exceeded
    private const int ERROR_CONCURRENT_EXCEEDED = -2147015898;     // 0x80072326 - Concurrent requests exceeded
    private const int ERROR_SQL_TIMEOUT = -2147204784;             // 0x80048110 - SQL timeout
    private const int ERROR_ASYNC_CANCELLED = -2147020463;         // 0x80044171 - Async operation cancelled
    private const int ERROR_SERVER_BUSY = -2147180287;             // 0x80060001 - Server busy
    private const int ERROR_SERVICE_UNAVAILABLE = -2147220891;     // 0x80040225 - Service temporarily unavailable
    private const int ERROR_RATE_LIMIT = -2147020449;              // 0x8004417F - Rate limit exceeded

    private static readonly int[] TransientErrorCodes =
    {
        ERROR_REQUESTS_EXCEEDED,
        ERROR_EXECUTION_TIME_EXCEEDED,
        ERROR_CONCURRENT_EXCEEDED,
        ERROR_SQL_TIMEOUT,
        ERROR_ASYNC_CANCELLED,
        ERROR_SERVER_BUSY,
        ERROR_SERVICE_UNAVAILABLE,
        ERROR_RATE_LIMIT
    };

    private readonly ServiceClient _client;
    private readonly DataverseSettings _settings;
    private readonly EntityMappingsConfig _mappings;
    private readonly SyncSettings _syncSettings;
    private readonly ILogger<DataverseClient> _logger;
    private readonly AsyncRetryPolicy _retryPolicy;

    public DataverseClient(
        IOptions<DataverseSettings> settings,
        IOptions<EntityMappingsConfig> mappings,
        IOptions<SyncSettings> syncSettings,
        IOptions<LocalServicePrincipalSettings> spSettings,
        ILogger<DataverseClient> logger)
    {
        _settings = settings.Value;
        _mappings = mappings.Value;
        _syncSettings = syncSettings.Value;
        _logger = logger;
        _client = CreateClient(spSettings.Value);

        // Create retry policy
        _retryPolicy = Policy
            .Handle<Exception>(IsTransientError)
            .WaitAndRetryAsync(
                retryCount: _syncSettings.MaxRetries,
                sleepDurationProvider: retryAttempt =>
                    TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                onRetry: (exception, timeSpan, retryCount, context) =>
                {
                    _logger.LogWarning(
                        "Retry {RetryCount}/{MaxRetries} after {Delay}s due to: {Error}",
                        retryCount,
                        _syncSettings.MaxRetries,
                        timeSpan.TotalSeconds,
                        exception.Message);
                });
    }

    private ServiceClient CreateClient(LocalServicePrincipalSettings sp)
    {
        var connectionString = $@"
            AuthType=ClientSecret;
            Url={_settings.EnvironmentUrl};
            ClientId={sp.ClientId};
            ClientSecret={sp.ClientSecret};
            TenantId={sp.TenantId};
            RequireNewInstance=True";

        _logger.LogInformation("Connecting to Dataverse: {Url}", _settings.EnvironmentUrl);

        var client = new ServiceClient(connectionString);

        if (!client.IsReady)
        {
            throw new InvalidOperationException(
                $"Failed to connect to Dataverse: {client.LastError}");
        }

        // Disable affinity cookie - allows requests to go to any server
        client.EnableAffinityCookie = false;

        _logger.LogInformation("Connected to Dataverse successfully (Affinity Cookie: disabled)");
        return client;
    }

    /// <summary>
    /// Gets a cloned client for thread-safe parallel operations.
    /// </summary>
    public ServiceClient GetThreadSafeClient()
    {
        return _client.Clone();
    }

    public async Task<Dictionary<string, Guid>> CheckExistenceAsync(
        EntityType entityType,
        IEnumerable<SyncRecord> records,
        CancellationToken cancellationToken = default)
    {
        var result = new Dictionary<string, Guid>();
        var mapping = GetMapping(entityType);
        var recordList = records.ToList();

        if (recordList.Count == 0 || mapping.AlternateKeys.Count == 0)
            return result;

        var keyField = mapping.AlternateKeys[0];
        var sourceKeyField = mapping.FieldMappings
            .FirstOrDefault(f => f.Value == keyField).Key;

        if (string.IsNullOrEmpty(sourceKeyField))
        {
            _logger.LogWarning("No source field mapping found for alternate key {KeyField}", keyField);
            return result;
        }

        var keyValues = recordList
            .Where(r => r.SourceData.ContainsKey(sourceKeyField) && r.SourceData[sourceKeyField] != null)
            .Select(r => r.SourceData[sourceKeyField]!.ToString()!)
            .Distinct()
            .ToList();

        if (keyValues.Count == 0)
            return result;

        _logger.LogDebug("Checking existence for {Count} records in {Entity}",
            keyValues.Count, mapping.DataverseTable);

        var query = new QueryExpression(mapping.DataverseTable)
        {
            ColumnSet = new ColumnSet(mapping.DataverseTable + "id", keyField),
            Criteria = new FilterExpression
            {
                Conditions =
                {
                    new ConditionExpression(keyField, ConditionOperator.In, keyValues.ToArray())
                }
            }
        };

        var response = await _client.RetrieveMultipleAsync(query, cancellationToken);

        foreach (var entity in response.Entities)
        {
            if (entity.Contains(keyField))
            {
                var keyValue = entity[keyField]?.ToString();
                if (!string.IsNullOrEmpty(keyValue))
                {
                    result[keyValue] = entity.Id;
                }
            }
        }

        _logger.LogDebug("Found {Count} existing records", result.Count);
        return result;
    }

    public async Task<IEnumerable<SyncRecordResult>> CreateAsync(
        EntityType entityType,
        IEnumerable<SyncRecord> records,
        CancellationToken cancellationToken = default)
    {
        var mapping = GetMapping(entityType);
        var recordList = records.ToList();
        var results = new List<SyncRecordResult>();

        if (recordList.Count == 0)
            return results;

        _logger.LogDebug("Executing CreateMultiple for {Count} records", recordList.Count);
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            // Use thread-safe cloned client
            using var threadClient = _client.Clone();

            // Build EntityCollection for CreateMultipleRequest
            var entities = new EntityCollection { EntityName = mapping.DataverseTable };

            foreach (var record in recordList)
            {
                var entity = MapToEntity(record, mapping);
                entities.Entities.Add(entity);
            }

            var request = new CreateMultipleRequest { Targets = entities };
            CreateMultipleResponse response = null!;

            await _retryPolicy.ExecuteAsync(async () =>
            {
                response = (CreateMultipleResponse)await threadClient.ExecuteAsync(request, cancellationToken);
            });

            stopwatch.Stop();
            _logger.LogInformation("CreateMultiple completed: {Count} records in {Ms}ms",
                recordList.Count, stopwatch.ElapsedMilliseconds);

            // Map results back to records
            for (int i = 0; i < recordList.Count; i++)
            {
                var record = recordList[i];
                var newId = i < response.Ids.Length ? response.Ids[i] : Guid.Empty;

                results.Add(new SyncRecordResult
                {
                    Record = record,
                    Success = newId != Guid.Empty,
                    DataverseId = newId != Guid.Empty ? newId : null,
                    ErrorMessage = newId == Guid.Empty ? "No ID returned" : null
                });
            }
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "CreateMultiple failed after {Ms}ms", stopwatch.ElapsedMilliseconds);

            // Mark all as failed
            foreach (var record in recordList)
            {
                results.Add(new SyncRecordResult
                {
                    Record = record,
                    Success = false,
                    ErrorMessage = ex.Message,
                    IsTransient = IsTransientError(ex)
                });
            }
        }

        return results;
    }

    public async Task<IEnumerable<SyncRecordResult>> UpdateAsync(
        EntityType entityType,
        IEnumerable<SyncRecord> records,
        CancellationToken cancellationToken = default)
    {
        var mapping = GetMapping(entityType);
        var recordList = records.ToList();
        var results = new List<SyncRecordResult>();

        if (recordList.Count == 0)
            return results;

        // Filter out records without DataverseId
        var validRecords = recordList.Where(r => r.DataverseId.HasValue).ToList();
        var invalidRecords = recordList.Where(r => !r.DataverseId.HasValue).ToList();

        // Add failures for invalid records
        foreach (var record in invalidRecords)
        {
            results.Add(new SyncRecordResult
            {
                Record = record,
                Success = false,
                ErrorMessage = "DataverseId is required for update",
                IsTransient = false
            });
        }

        if (validRecords.Count == 0)
            return results;

        _logger.LogDebug("Executing UpdateMultiple for {Count} records", validRecords.Count);
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            using var threadClient = _client.Clone();

            // Build EntityCollection for UpdateMultipleRequest
            var entities = new EntityCollection { EntityName = mapping.DataverseTable };

            foreach (var record in validRecords)
            {
                var entity = MapToEntity(record, mapping);
                entity.Id = record.DataverseId!.Value;
                entities.Entities.Add(entity);
            }

            var request = new UpdateMultipleRequest { Targets = entities };

            await _retryPolicy.ExecuteAsync(async () =>
            {
                await threadClient.ExecuteAsync(request, cancellationToken);
            });

            stopwatch.Stop();
            _logger.LogInformation("UpdateMultiple completed: {Count} records in {Ms}ms",
                validRecords.Count, stopwatch.ElapsedMilliseconds);

            // All succeeded
            foreach (var record in validRecords)
            {
                results.Add(new SyncRecordResult
                {
                    Record = record,
                    Success = true,
                    DataverseId = record.DataverseId
                });
            }
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "UpdateMultiple failed after {Ms}ms", stopwatch.ElapsedMilliseconds);

            foreach (var record in validRecords)
            {
                results.Add(new SyncRecordResult
                {
                    Record = record,
                    Success = false,
                    ErrorMessage = ex.Message,
                    IsTransient = IsTransientError(ex)
                });
            }
        }

        return results;
    }

    public async Task<IEnumerable<SyncRecordResult>> DeactivateAsync(
        EntityType entityType,
        IEnumerable<SyncRecord> records,
        CancellationToken cancellationToken = default)
    {
        var results = new List<SyncRecordResult>();
        var mapping = GetMapping(entityType);
        var recordList = records.ToList();

        if (recordList.Count == 0)
            return results;

        _logger.LogDebug("Executing Deactivate for {Count} records", recordList.Count);
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();

        // Deactivate doesn't have a "Multiple" version, so we use ExecuteMultiple
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            using var threadClient = _client.Clone();

            var requests = new OrganizationRequestCollection();
            var recordMap = new Dictionary<int, SyncRecord>();
            var index = 0;

            foreach (var record in recordList)
            {
                if (!record.DataverseId.HasValue)
                {
                    results.Add(new SyncRecordResult
                    {
                        Record = record,
                        Success = false,
                        ErrorMessage = "DataverseId is required for deactivation",
                        IsTransient = false
                    });
                    continue;
                }

                var request = new SetStateRequest
                {
                    EntityMoniker = new EntityReference(mapping.DataverseTable, record.DataverseId.Value),
                    State = new OptionSetValue(1),
                    Status = new OptionSetValue(-1)
                };

                requests.Add(request);
                recordMap[index++] = record;
            }

            if (requests.Count > 0)
            {
                var executeMultiple = new ExecuteMultipleRequest
                {
                    Requests = requests,
                    Settings = new ExecuteMultipleSettings
                    {
                        ContinueOnError = true,
                        ReturnResponses = true
                    }
                };

                ExecuteMultipleResponse response = null!;
                await _retryPolicy.ExecuteAsync(async () =>
                {
                    response = (ExecuteMultipleResponse)await threadClient.ExecuteAsync(executeMultiple, cancellationToken);
                });

                stopwatch.Stop();
                _logger.LogInformation("Deactivate completed: {Count} records in {Ms}ms",
                    requests.Count, stopwatch.ElapsedMilliseconds);

                // Process responses
                foreach (var kvp in recordMap)
                {
                    var responseItem = response.Responses.FirstOrDefault(r => r.RequestIndex == kvp.Key);

                    if (responseItem?.Fault != null)
                    {
                        results.Add(new SyncRecordResult
                        {
                            Record = kvp.Value,
                            Success = false,
                            ErrorMessage = responseItem.Fault.Message,
                            ErrorCode = responseItem.Fault.ErrorCode.ToString(),
                            IsTransient = IsTransientError(responseItem.Fault)
                        });
                    }
                    else
                    {
                        results.Add(new SyncRecordResult
                        {
                            Record = kvp.Value,
                            Success = true,
                            DataverseId = kvp.Value.DataverseId
                        });
                    }
                }
            }
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Deactivate failed after {Ms}ms", stopwatch.ElapsedMilliseconds);

            foreach (var record in recordList.Where(r => r.DataverseId.HasValue))
            {
                if (!results.Any(r => r.Record == record))
                {
                    results.Add(new SyncRecordResult
                    {
                        Record = record,
                        Success = false,
                        ErrorMessage = ex.Message,
                        IsTransient = IsTransientError(ex)
                    });
                }
            }
        }

        return results;
    }

    private EntityMappingConfig GetMapping(EntityType entityType)
    {
        return entityType switch
        {
            EntityType.PhysicalPerson => _mappings.PhysicalPerson,
            EntityType.Contact => _mappings.Contact,
            EntityType.Account => _mappings.Account,
            _ => throw new ArgumentOutOfRangeException(nameof(entityType))
        };
    }

    private Entity MapToEntity(SyncRecord record, EntityMappingConfig mapping)
    {
        var entity = new Entity(mapping.DataverseTable);

        foreach (var fieldMap in mapping.FieldMappings)
        {
            var sourceField = fieldMap.Key;
            var targetField = fieldMap.Value;

            if (record.SourceData.TryGetValue(sourceField, out var value) && value != null)
            {
                entity[targetField] = value;
            }
        }

        return entity;
    }

    private bool IsTransientError(OrganizationServiceFault fault)
    {
        // Check error code against known transient codes
        if (TransientErrorCodes.Contains(fault.ErrorCode))
            return true;

        // Check message for common transient patterns
        var message = fault.Message ?? string.Empty;
        return ContainsTransientPattern(message);
    }

    private bool IsTransientError(Exception ex)
    {
        var message = ex.Message ?? string.Empty;
        return ContainsTransientPattern(message);
    }

    private static bool ContainsTransientPattern(string message)
    {
        var transientPatterns = new[]
        {
        "timeout",
        "throttl",
        "too many requests",
        "service unavailable",
        "server busy",
        "rate limit",
        "try again",
        "temporarily unavailable",
        "gateway"
    };

        return transientPatterns.Any(pattern =>
            message.Contains(pattern, StringComparison.OrdinalIgnoreCase));
    }
    public void Dispose()
    {
        _client?.Dispose();
        GC.SuppressFinalize(this);
    }
}