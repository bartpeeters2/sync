﻿using System.Collections.Concurrent;
using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MA.DataSync.Core.Configuration;
using MA.DataSync.Core.Entities;
using MA.DataSync.Core.Enums;
using MA.DataSync.Core.Interfaces;

namespace MA.DataSync.Application.Pipeline;

/// <summary>
/// Processes records in batches with parallel execution.
/// </summary>
public class BatchProcessor : IBatchProcessor
{
    private readonly IDataverseClient _dataverseClient;
    private readonly SyncSettings _settings;
    private readonly EntityMappingsConfig _mappings;
    private readonly ILogger<BatchProcessor> _logger;

    public BatchProcessor(
        IDataverseClient dataverseClient,
        IOptions<SyncSettings> settings,
        IOptions<EntityMappingsConfig> mappings,
        ILogger<BatchProcessor> logger)
    {
        _dataverseClient = dataverseClient;
        _settings = settings.Value;
        _mappings = mappings.Value;
        _logger = logger;
    }

    public async Task<BatchProcessingResult> ProcessAsync(
        EntityType entityType,
        IEnumerable<SyncRecord> records,
        SyncRunContext context,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        var result = new BatchProcessingResult();
        var recordList = records.ToList();

        if (recordList.Count == 0)
        {
            _logger.LogInformation("No records to process for {EntityType}", entityType);
            return result;
        }

        _logger.LogInformation(
            "Processing {Count} {EntityType} records (BatchSize: {BatchSize}, MaxParallel: {MaxParallel})",
            recordList.Count, entityType, _settings.BatchSize, _settings.MaxConcurrentBatches);

        // Step 1: Check existence in Dataverse (bulk)
        await CheckExistenceAsync(entityType, recordList, cancellationToken);

        // Step 2: Determine operations (Create, Update, Delete, Skip)
        DetermineOperations(recordList);

        // Step 3: Group by operation
        var creates = recordList.Where(r => r.Operation == SyncOperation.Create).ToList();
        var updates = recordList.Where(r => r.Operation == SyncOperation.Update).ToList();
        var deletes = recordList.Where(r => r.Operation == SyncOperation.Delete).ToList();
        var skips = recordList.Where(r => r.Operation == SyncOperation.Skip).ToList();

        _logger.LogInformation(
            "Operations: {Creates} creates, {Updates} updates, {Deletes} deletes, {Skips} skips",
            creates.Count, updates.Count, deletes.Count, skips.Count);

        // Step 4: Process each operation type in parallel batches
        var createResults = await ProcessOperationAsync(entityType, creates, SyncOperation.Create, cancellationToken);
        var updateResults = await ProcessOperationAsync(entityType, updates, SyncOperation.Update, cancellationToken);
        var deleteResults = await ProcessOperationAsync(entityType, deletes, SyncOperation.Delete, cancellationToken);

        // Step 5: Aggregate results
        stopwatch.Stop();

        result.TotalProcessed = recordList.Count;
        result.Created = createResults.succeeded;
        result.Updated = updateResults.succeeded;
        result.Deleted = deleteResults.succeeded;
        result.Skipped = skips.Count;
        result.Succeeded = result.Created + result.Updated + result.Deleted + result.Skipped;
        result.Failed = createResults.failed + updateResults.failed + deleteResults.failed;
        result.FailedRecords = createResults.failedRecords
            .Concat(updateResults.failedRecords)
            .Concat(deleteResults.failedRecords)
            .ToList();
        result.ProcessingTimeMs = stopwatch.ElapsedMilliseconds;

        _logger.LogInformation(
            "Completed {EntityType}: {Succeeded} succeeded, {Failed} failed in {Time}ms",
            entityType, result.Succeeded, result.Failed, result.ProcessingTimeMs);

        return result;
    }

    private async Task CheckExistenceAsync(
       EntityType entityType,
       List<SyncRecord> records,
       CancellationToken cancellationToken)
    {
        _logger.LogDebug("Checking existence for {Count} records", records.Count);

        // Get the mapping to find the correct alternate key field
        var mapping = GetMapping(entityType);

        if (mapping.AlternateKeys.Count == 0)
        {
            _logger.LogWarning("No alternate keys configured for {EntityType}, skipping existence check", entityType);
            return;
        }

        var alternateKeyField = mapping.AlternateKeys[0]; // Dataverse field name
        var sourceKeyField = mapping.FieldMappings
            .FirstOrDefault(f => f.Value == alternateKeyField).Key; // BigQuery column name

        if (string.IsNullOrEmpty(sourceKeyField))
        {
            _logger.LogWarning("No source field mapping found for alternate key {KeyField}", alternateKeyField);
            return;
        }

        // Process in batches for existence check
        var batches = records.Chunk(_settings.BatchSize).ToList();

        foreach (var batch in batches)
        {
            if (cancellationToken.IsCancellationRequested)
                break;

            var existingRecords = await _dataverseClient.CheckExistenceAsync(
                entityType, batch, cancellationToken);

            // Match using the SPECIFIC alternate key field
            foreach (var record in batch)
            {
                if (record.SourceData.TryGetValue(sourceKeyField, out var keyValue) && keyValue != null)
                {
                    var keyString = keyValue.ToString();
                    if (!string.IsNullOrEmpty(keyString) && existingRecords.TryGetValue(keyString, out var dataverseId))
                    {
                        record.DataverseId = dataverseId;
                    }
                }
            }
        }

        var existingCount = records.Count(r => r.DataverseId.HasValue);
        _logger.LogDebug("Found {Existing} existing records out of {Total}", existingCount, records.Count);
    }

    private EntityMappingConfig GetMapping(EntityType entityType)
    {
        return entityType switch
        {
            EntityType.PhysicalPerson => _mappings.PhysicalPerson,
            EntityType.Contact => _mappings.Contact,
            EntityType.Account => _mappings.Account,
            _ => throw new ArgumentOutOfRangeException(nameof(entityType))
        };
    }

    private void DetermineOperations(List<SyncRecord> records)
    {
        foreach (var record in records)
        {
            if (record.IsDeleted)
            {
                // Record marked as deleted in source
                record.Operation = record.DataverseId.HasValue
                    ? SyncOperation.Delete  // Exists in Dataverse - deactivate it
                    : SyncOperation.Skip;   // Doesn't exist - nothing to do
            }
            else if (record.DataverseId.HasValue)
            {
                // Record exists in Dataverse - update it
                record.Operation = SyncOperation.Update;
            }
            else
            {
                // Record doesn't exist in Dataverse - create it
                record.Operation = SyncOperation.Create;
            }
        }
    }

    private async Task<(int succeeded, int failed, List<SyncRecord> failedRecords)> ProcessOperationAsync(
        EntityType entityType,
        List<SyncRecord> records,
        SyncOperation operation,
        CancellationToken cancellationToken)
    {
        if (records.Count == 0)
            return (0, 0, new List<SyncRecord>());

        var succeeded = 0;
        var failed = 0;
        var failedRecords = new ConcurrentBag<SyncRecord>();

        // Split into batches
        var batches = records.Chunk(_settings.BatchSize).ToList();

        _logger.LogDebug(
            "Processing {Operation}: {Records} records in {Batches} batches",
            operation, records.Count, batches.Count);

        // Process batches in parallel
        var parallelOptions = new ParallelOptions
        {
            MaxDegreeOfParallelism = _settings.MaxConcurrentBatches,
            CancellationToken = cancellationToken
        };

        await Parallel.ForEachAsync(batches, parallelOptions, async (batch, ct) =>
        {
            var batchList = batch.ToList();
            IEnumerable<SyncRecordResult> results;

            try
            {
                results = operation switch
                {
                    SyncOperation.Create => await _dataverseClient.CreateAsync(entityType, batchList, ct),
                    SyncOperation.Update => await _dataverseClient.UpdateAsync(entityType, batchList, ct),
                    SyncOperation.Delete => await _dataverseClient.DeactivateAsync(entityType, batchList, ct),
                    _ => Enumerable.Empty<SyncRecordResult>()
                };

                foreach (var result in results)
                {
                    if (result.Success)
                    {
                        result.Record.Status = SyncStatus.Success;
                        result.Record.DataverseId = result.DataverseId;
                        Interlocked.Increment(ref succeeded);
                    }
                    else
                    {
                        result.Record.Status = result.IsTransient
                            ? SyncStatus.TransientFailure
                            : SyncStatus.PermanentFailure;
                        result.Record.ErrorMessage = result.ErrorMessage;
                        result.Record.RetryCount++;

                        Interlocked.Increment(ref failed);
                        failedRecords.Add(result.Record);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Batch {Operation} failed", operation);

                foreach (var record in batchList)
                {
                    record.Status = SyncStatus.TransientFailure;
                    record.ErrorMessage = ex.Message;
                    record.RetryCount++;

                    Interlocked.Increment(ref failed);
                    failedRecords.Add(record);
                }
            }
        });

        return (succeeded, failed, failedRecords.ToList());
    }
}