﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Retry;
using MA.DataSync.Core.Configuration;

namespace MA.DataSync.Application.Resilience;

/// <summary>
/// Provides retry policies for transient failures.
/// Uses Polly for exponential backoff with jitter.
/// </summary>
public class RetryPolicyService
{
    private readonly SyncSettings _settings;
    private readonly ILogger<RetryPolicyService> _logger;

    public RetryPolicyService(
        IOptions<SyncSettings> settings,
        ILogger<RetryPolicyService> logger)
    {
        _settings = settings.Value;
        _logger = logger;
    }

    /// <summary>
    /// Creates a retry policy for Dataverse operations.
    /// Retries on transient errors with exponential backoff.
    /// </summary>
    public AsyncRetryPolicy CreateDataverseRetryPolicy()
    {
        return Policy
            .Handle<Exception>(IsTransientException)
            .WaitAndRetryAsync(
                retryCount: _settings.MaxRetries,
                sleepDurationProvider: GetRetryDelay,
                onRetry: (exception, timeSpan, retryCount, context) =>
                {
                    _logger.LogWarning(
                        "Retry {RetryCount}/{MaxRetries} after {Delay}ms due to: {Error}",
                        retryCount,
                        _settings.MaxRetries,
                        timeSpan.TotalMilliseconds,
                        exception.Message);
                });
    }

    /// <summary>
    /// Creates a retry policy for BigQuery operations.
    /// </summary>
    public AsyncRetryPolicy CreateBigQueryRetryPolicy()
    {
        return Policy
            .Handle<Exception>(IsBigQueryTransientException)
            .WaitAndRetryAsync(
                retryCount: _settings.MaxRetries,
                sleepDurationProvider: GetRetryDelay,
                onRetry: (exception, timeSpan, retryCount, context) =>
                {
                    _logger.LogWarning(
                        "BigQuery retry {RetryCount}/{MaxRetries} after {Delay}ms due to: {Error}",
                        retryCount,
                        _settings.MaxRetries,
                        timeSpan.TotalMilliseconds,
                        exception.Message);
                });
    }

    /// <summary>
    /// Executes an action with Dataverse retry policy.
    /// </summary>
    public async Task<T> ExecuteWithRetryAsync<T>(
        Func<Task<T>> action,
        string operationName)
    {
        var policy = CreateDataverseRetryPolicy();

        try
        {
            return await policy.ExecuteAsync(action);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Operation {Operation} failed after {MaxRetries} retries",
                operationName, _settings.MaxRetries);
            throw;
        }
    }

    /// <summary>
    /// Executes an action with Dataverse retry policy (no return value).
    /// </summary>
    public async Task ExecuteWithRetryAsync(
        Func<Task> action,
        string operationName)
    {
        var policy = CreateDataverseRetryPolicy();

        try
        {
            await policy.ExecuteAsync(action);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Operation {Operation} failed after {MaxRetries} retries",
                operationName, _settings.MaxRetries);
            throw;
        }
    }

    /// <summary>
    /// Calculates retry delay with exponential backoff and jitter.
    /// </summary>
    private TimeSpan GetRetryDelay(int retryAttempt)
    {
        // Exponential backoff: 2^attempt seconds (2s, 4s, 8s, 16s, ...)
        var exponentialDelay = TimeSpan.FromSeconds(Math.Pow(2, retryAttempt));

        // Add jitter (±20%) to prevent thundering herd
        var jitter = TimeSpan.FromMilliseconds(Random.Shared.Next(-200, 200) * retryAttempt);

        // Cap at 60 seconds
        var totalDelay = exponentialDelay + jitter;
        var maxDelay = TimeSpan.FromSeconds(60);

        return totalDelay > maxDelay ? maxDelay : totalDelay;
    }

    /// <summary>
    /// Determines if an exception is transient (retryable) for Dataverse.
    /// </summary>
    private bool IsTransientException(Exception ex)
    {
        var message = ex.Message?.ToLowerInvariant() ?? string.Empty;

        // Check for common transient patterns
        var transientPatterns = new[]
        {
            "timeout",
            "throttl",
            "too many requests",
            "service unavailable",
            "server busy",
            "rate limit",
            "try again",
            "temporarily unavailable",
            "gateway",
            "connection",
            "socket",
            "network"
        };

        if (transientPatterns.Any(pattern => message.Contains(pattern)))
            return true;

        // Check inner exception
        if (ex.InnerException != null)
            return IsTransientException(ex.InnerException);

        return false;
    }

    /// <summary>
    /// Determines if an exception is transient for BigQuery.
    /// </summary>
    private bool IsBigQueryTransientException(Exception ex)
    {
        var message = ex.Message?.ToLowerInvariant() ?? string.Empty;

        var transientPatterns = new[]
        {
            "timeout",
            "deadline exceeded",
            "unavailable",
            "internal error",
            "try again",
            "rate limit",
            "quota"
        };

        return transientPatterns.Any(pattern => message.Contains(pattern));
    }
}