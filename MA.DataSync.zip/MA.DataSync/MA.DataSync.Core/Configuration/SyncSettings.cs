﻿namespace MA.DataSync.Core.Configuration;

/// <summary>
/// General sync settings.
/// Maps to "Sync" section in appsettings.json.
/// </summary>
public class SyncSettings
{
    /// <summary>
    /// Number of records per batch for Dataverse operations.
    /// Default: 100. Max: 1000 (Dataverse limit).
    /// </summary>
    public int BatchSize { get; set; } = 100;

    /// <summary>
    /// Maximum retry attempts for transient failures.
    /// </summary>
    public int MaxRetries { get; set; } = 3;

    /// <summary>
    /// Hours to look back from watermark for safety overlap.
    /// Ensures we don't miss records due to timing issues.
    /// </summary>
    public int OverlapWindowHours { get; set; } = 6;

    /// <summary>
    /// Maximum parallel threads for processing records.
    /// </summary>
    public int MaxDegreeOfParallelism { get; set; } = 4;

    /// <summary>
    /// Maximum batches that can be sent to Dataverse concurrently.
    /// </summary>
    public int MaxConcurrentBatches { get; set; } = 3;
}