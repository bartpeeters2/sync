﻿namespace MA.DataSync.Core.Enums;

/// <summary>
/// Represents the result status of a sync operation for a record.
/// </summary>
public enum SyncStatus
{
    /// <summary>
    /// Record synced successfully.
    /// </summary>
    Success,

    /// <summary>
    /// Record sync failed but can be retried.
    /// </summary>
    TransientFailure,

    /// <summary>
    /// Record sync failed permanently - will go to DLQ.
    /// </summary>
    PermanentFailure,

    /// <summary>
    /// Record was skipped (no action needed).
    /// </summary>
    Skipped,

    /// <summary>
    /// Record is pending processing.
    /// </summary>
    Pending
}
