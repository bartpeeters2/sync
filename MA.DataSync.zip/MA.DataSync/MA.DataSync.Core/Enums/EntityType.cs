﻿namespace MA.DataSync.Core.Enums;

/// <summary>
/// Defines the entity types that can be synced.
/// Order matters - sync happens in this order for referential integrity.
/// </summary>
public enum EntityType
{
    /// <summary>
    /// Physical person entity - synced first.
    /// </summary>
    PhysicalPerson = 1,

    /// <summary>
    /// Contact entity - synced second (may reference PhysicalPerson).
    /// </summary>
    Contact = 2,

    /// <summary>
    /// Account entity - synced last.
    /// </summary>
    Account = 3
}

