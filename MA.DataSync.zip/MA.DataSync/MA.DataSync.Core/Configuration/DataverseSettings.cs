﻿namespace MA.DataSync.Core.Configuration;

/// <summary>
/// Dataverse connection and throttling settings.
/// Maps to "Dataverse" section in appsettings.json.
/// </summary>
public class DataverseSettings
{
    /// <summary>
    /// Dataverse environment URL.
    /// Example: "https://your-org.crm.dynamics.com"
    /// </summary>
    public string EnvironmentUrl { get; set; } = string.Empty;

    /// <summary>
    /// Maximum concurrent connections per Service Principal.
    /// </summary>
    public int MaxConnectionsPerServicePrincipal { get; set; } = 2;

    /// <summary>
    /// Maximum requests per minute per Service Principal.
    /// Dataverse limit: ~6000 per 5 minutes = 1200 per minute.
    /// </summary>
    public int RequestsPerMinutePerSP { get; set; } = 1000;
}