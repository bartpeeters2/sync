﻿using MA.DataSync.Core.Entities;
using MA.DataSync.Core.Enums;

namespace MA.DataSync.Core.Interfaces;

/// <summary>
/// Maps fields between BigQuery source data and Dataverse entities.
/// Handles field name mapping and value transformations.
/// </summary>
public interface IEntityMapper
{
    /// <summary>
    /// Maps a SyncRecord's source data to Dataverse field format.
    /// </summary>
    /// <param name="record">The record with source data from BigQuery.</param>
    /// <returns>Dictionary of Dataverse field names and values.</returns>
    Dictionary<string, object?> MapToDataverse(SyncRecord record);

    /// <summary>
    /// Gets the alternate key field name(s) for an entity type in Dataverse.
    /// </summary>
    /// <param name="entityType">The entity type.</param>
    /// <returns>List of field names that form the alternate key.</returns>
    IReadOnlyList<string> GetAlternateKeyFields(EntityType entityType);

    /// <summary>
    /// Gets the Dataverse logical name for an entity type.
    /// </summary>
    /// <param name="entityType">The entity type.</param>
    /// <returns>Dataverse entity logical name (e.g., "contact", "account").</returns>
    string GetDataverseEntityName(EntityType entityType);

    /// <summary>
    /// Gets the BigQuery table name for an entity type.
    /// </summary>
    /// <param name="entityType">The entity type.</param>
    /// <returns>BigQuery table name (e.g., "contact_latest").</returns>
    string GetBigQueryTableName(EntityType entityType);

    /// <summary>
    /// Gets the modified date column name in BigQuery for an entity type.
    /// </summary>
    /// <param name="entityType">The entity type.</param>
    /// <returns>Column name for watermark filtering.</returns>
    string GetModifiedDateColumn(EntityType entityType);

    /// <summary>
    /// Gets the delete flag column name in BigQuery for an entity type.
    /// </summary>
    /// <param name="entityType">The entity type.</param>
    /// <returns>Column name for delete detection.</returns>
    string GetDeleteFlagColumn(EntityType entityType);
}
