﻿namespace MA.DataSync.Core.Configuration;

/// <summary>
/// BigQuery connection settings.
/// Maps to "BigQuery" section in appsettings.json.
/// </summary>
public class BigQuerySettings
{
    /// <summary>
    /// Google Cloud Project ID.
    /// </summary>
    public string ProjectId { get; set; } = string.Empty;

    /// <summary>
    /// BigQuery Dataset ID containing the source tables.
    /// </summary>
    public string DatasetId { get; set; } = string.Empty;

    /// <summary>
    /// Path to the service account key JSON file.
    /// Used for local development. In production (Cloud Run), 
    /// uses workload identity instead.
    /// </summary>
    public string? ServiceAccountKeyPath { get; set; }
}