﻿using MA.DataSync.Core.Entities;

namespace MA.DataSync.Core.Interfaces;

/// <summary>
/// Repository for storing permanently failed records in BigQuery.
/// These records need manual investigation and potential retry.
/// </summary>
public interface IDeadLetterRepository
{
    /// <summary>
    /// Writes a failed record to the Dead-Letter Queue.
    /// </summary>
    /// <param name="record">The failed record with error details.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    Task WriteAsync(
        DeadLetterRecord record,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Writes multiple failed records to the Dead-Letter Queue.
    /// More efficient than writing one at a time.
    /// </summary>
    /// <param name="records">The failed records.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    Task WriteBatchAsync(
        IEnumerable<DeadLetterRecord> records,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets the count of unresolved DLQ records for a run.
    /// </summary>
    /// <param name="runId">The run ID to check.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>Number of unresolved records.</returns>
    Task<int> GetUnresolvedCountAsync(
        string runId,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets the total count of unresolved DLQ records.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>Total number of unresolved records.</returns>
    Task<int> GetTotalUnresolvedCountAsync(
        CancellationToken cancellationToken = default);
}
