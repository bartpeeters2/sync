﻿using Google.Cloud.BigQuery.V2;
using Google.Apis.Auth.OAuth2;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MA.DataSync.Core.Configuration;
using MA.DataSync.Core.Entities;
using MA.DataSync.Core.Interfaces;
using System.Text.Json;

namespace MA.DataSync.Infrastructure.BigQuery;

/// <summary>
/// Repository for storing failed records in BigQuery Dead-Letter Queue.
/// Table must be created via Terraform before running the app.
/// </summary>
public class DeadLetterRepository : IDeadLetterRepository
{
    private readonly BigQueryClient _client;
    private readonly BigQuerySettings _settings;
    private readonly ILogger<DeadLetterRepository> _logger;

    private const string DeadLetterTableName = "sync_dead_letter";
    private bool _tableVerified = false;

    public DeadLetterRepository(
        IOptions<BigQuerySettings> settings,
        ILogger<DeadLetterRepository> logger)
    {
        _settings = settings.Value;
        _logger = logger;
        _client = CreateClient();
    }

    private BigQueryClient CreateClient()
    {
        if (!string.IsNullOrEmpty(_settings.ServiceAccountKeyPath))
        {
            var credential = GoogleCredential.FromFile(_settings.ServiceAccountKeyPath);
            return BigQueryClient.Create(_settings.ProjectId, credential);
        }

        return BigQueryClient.Create(_settings.ProjectId);
    }

    private async Task EnsureTableExistsAsync(CancellationToken cancellationToken)
    {
        if (_tableVerified) return;

        var tableId = $"`{_settings.ProjectId}.{_settings.DatasetId}.{DeadLetterTableName}`";
        var sql = $"SELECT 1 FROM {tableId} LIMIT 0";

        try
        {
            await _client.ExecuteQueryAsync(sql, parameters: null, cancellationToken: cancellationToken);
            _logger.LogDebug("Dead-letter table verified: {Table}", DeadLetterTableName);
            _tableVerified = true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Required table does not exist: {Table}. Please create it via Terraform.", tableId);
            throw new InvalidOperationException(
                $"Required table '{tableId}' does not exist. Please create it via Terraform before running the sync.", ex);
        }
    }

    public async Task WriteAsync(
        DeadLetterRecord record,
        CancellationToken cancellationToken = default)
    {
        await EnsureTableExistsAsync(cancellationToken);

        var tableId = $"`{_settings.ProjectId}.{_settings.DatasetId}.{DeadLetterTableName}`";

        var sql = $@"
            INSERT INTO {tableId} 
            (id, run_id, entity_type, operation, alternate_keys, source_data, 
             error_message, error_code, retry_attempts, failed_at, is_resolved)
            VALUES 
            (@id, @runId, @entityType, @operation, @alternateKeys, @sourceData,
             @errorMessage, @errorCode, @retryAttempts, @failedAt, @isResolved)";

        var parameters = new[]
        {
            new BigQueryParameter("id", BigQueryDbType.String, record.Id),
            new BigQueryParameter("runId", BigQueryDbType.String, record.RunId),
            new BigQueryParameter("entityType", BigQueryDbType.String, record.EntityType.ToString()),
            new BigQueryParameter("operation", BigQueryDbType.String, record.Operation.ToString()),
            new BigQueryParameter("alternateKeys", BigQueryDbType.String,
                JsonSerializer.Serialize(record.AlternateKeys)),
            new BigQueryParameter("sourceData", BigQueryDbType.String,
                JsonSerializer.Serialize(record.SourceData)),
            new BigQueryParameter("errorMessage", BigQueryDbType.String, record.ErrorMessage),
            new BigQueryParameter("errorCode", BigQueryDbType.String, record.DataverseErrorCode),
            new BigQueryParameter("retryAttempts", BigQueryDbType.Int64, record.RetryAttempts),
            new BigQueryParameter("failedAt", BigQueryDbType.Timestamp,
                DateTime.SpecifyKind(record.FailedAt, DateTimeKind.Utc)),
            new BigQueryParameter("isResolved", BigQueryDbType.Bool, record.IsResolved)
        };

        await _client.ExecuteQueryAsync(sql, parameters, cancellationToken: cancellationToken);
        _logger.LogDebug("Wrote dead-letter record: {Id}", record.Id);
    }

    public async Task WriteBatchAsync(
        IEnumerable<DeadLetterRecord> records,
        CancellationToken cancellationToken = default)
    {
        var recordList = records.ToList();
        if (recordList.Count == 0) return;

        await EnsureTableExistsAsync(cancellationToken);

        _logger.LogInformation("Writing {Count} records to dead-letter queue", recordList.Count);

        foreach (var record in recordList)
        {
            try
            {
                await WriteAsync(record, cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to write dead-letter record: {Id}", record.Id);
            }
        }

        _logger.LogInformation("Completed writing to dead-letter queue");
    }

    public async Task<int> GetUnresolvedCountAsync(
        string runId,
        CancellationToken cancellationToken = default)
    {
        await EnsureTableExistsAsync(cancellationToken);

        var tableId = $"`{_settings.ProjectId}.{_settings.DatasetId}.{DeadLetterTableName}`";
        var sql = $"SELECT COUNT(*) as count FROM {tableId} WHERE run_id = @runId AND is_resolved = FALSE";

        var parameters = new[]
        {
            new BigQueryParameter("runId", BigQueryDbType.String, runId)
        };

        var results = await _client.ExecuteQueryAsync(sql, parameters, cancellationToken: cancellationToken);
        var row = results.FirstOrDefault();

        var count = row?["count"] switch
        {
            long l => (int)l,
            int i => i,
            _ => 0
        };

        _logger.LogDebug("Unresolved dead-letter records for run {RunId}: {Count}", runId, count);
        return count;
    }

    public async Task<int> GetTotalUnresolvedCountAsync(
        CancellationToken cancellationToken = default)
    {
        await EnsureTableExistsAsync(cancellationToken);

        var tableId = $"`{_settings.ProjectId}.{_settings.DatasetId}.{DeadLetterTableName}`";
        var sql = $"SELECT COUNT(*) as count FROM {tableId} WHERE is_resolved = FALSE";

        var results = await _client.ExecuteQueryAsync(sql, parameters: null, cancellationToken: cancellationToken);
        var row = results.FirstOrDefault();

        var count = row?["count"] switch
        {
            long l => (int)l,
            int i => i,
            _ => 0
        };

        _logger.LogDebug("Total unresolved dead-letter records: {Count}", count);
        return count;
    }
}