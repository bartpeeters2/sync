﻿namespace MA.DataSync.Core.Interfaces;

/// <summary>
/// Orchestrates the entire sync process.
/// Handles streaming, checkpointing, and error recovery.
/// </summary>
public interface ISyncOrchestrator
{
    /// <summary>
    /// Runs the complete sync process for all configured entities.
    /// Processes in order: PhysicalPerson → Contact → Account.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token for graceful shutdown.</param>
    /// <returns>True if sync completed successfully, false if errors occurred.</returns>
    Task<bool> RunAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Runs sync for a specific entity type only.
    /// </summary>
    /// <param name="entityType">The entity type to sync.</param>
    /// <param name="cancellationToken">Cancellation token for graceful shutdown.</param>
    /// <returns>True if sync completed successfully, false if errors occurred.</returns>
    Task<bool> RunForEntityAsync(
        Core.Enums.EntityType entityType,
        CancellationToken cancellationToken = default);
}