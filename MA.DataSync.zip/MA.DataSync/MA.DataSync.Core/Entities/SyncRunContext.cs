﻿using MA.DataSync.Core.Enums;

namespace MA.DataSync.Core.Entities;

/// <summary>
/// Represents a single execution of the sync job.
/// Tracks progress, timing, and results across all entities.
/// </summary>
public class SyncRunContext
{
    /// <summary>
    /// Unique identifier for this run.
    /// Used in all logs and checkpoints for traceability.
    /// </summary>
    public string RunId { get; set; } = Guid.NewGuid().ToString();

    /// <summary>
    /// When this run started.
    /// </summary>
    public DateTime StartedAt { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// When this run completed (null if still running).
    /// </summary>
    public DateTime? CompletedAt { get; set; }

    /// <summary>
    /// Is this run resuming from a previous incomplete run?
    /// </summary>
    public bool IsResuming { get; set; }

    /// <summary>
    /// The RunId of the previous incomplete run (if resuming).
    /// </summary>
    public string? ResumingFromRunId { get; set; }

    /// <summary>
    /// Current entity being processed.
    /// </summary>
    public EntityType? CurrentEntity { get; set; }

    /// <summary>
    /// Overall status of the run.
    /// </summary>
    public SyncRunStatus Status { get; set; } = SyncRunStatus.Running;

    /// <summary>
    /// Statistics per entity type.
    /// </summary>
    public Dictionary<EntityType, EntitySyncStats> EntityStats { get; set; } = new();

    /// <summary>
    /// Total records processed across all entities.
    /// </summary>
    public int TotalRecordsProcessed => EntityStats.Values.Sum(s => s.TotalProcessed);

    /// <summary>
    /// Total records that succeeded across all entities.
    /// </summary>
    public int TotalSucceeded => EntityStats.Values.Sum(s => s.Succeeded);

    /// <summary>
    /// Total records that failed across all entities.
    /// </summary>
    public int TotalFailed => EntityStats.Values.Sum(s => s.Failed);

    /// <summary>
    /// Total run duration.
    /// </summary>
    public TimeSpan? Duration => CompletedAt.HasValue
        ? CompletedAt.Value - StartedAt
        : DateTime.UtcNow - StartedAt;

    /// <summary>
    /// Cancellation token source for graceful shutdown.
    /// </summary>
    public CancellationTokenSource CancellationTokenSource { get; set; } = new();
}

/// <summary>
/// Status of the overall sync run.
/// </summary>
public enum SyncRunStatus
{
    Running,
    CompletedSuccess,
    CompletedWithErrors,
    Failed,
    Cancelled
}

/// <summary>
/// Statistics for a single entity type within a run.
/// </summary>
public class EntitySyncStats
{
    public EntityType EntityType { get; set; }
    public int TotalExtracted { get; set; }
    public int TotalProcessed { get; set; }
    public int Succeeded { get; set; }
    public int Failed { get; set; }
    public int Skipped { get; set; }
    public int Created { get; set; }
    public int Updated { get; set; }
    public int Deleted { get; set; }
    public int SentToDlq { get; set; }
    public DateTime? StartedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public string? LastCheckpointId { get; set; }
    public TimeSpan ProcessingTime { get; set; }
}