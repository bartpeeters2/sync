﻿using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MA.DataSync.Core.Configuration;
using MA.DataSync.Core.Entities;
using MA.DataSync.Core.Enums;
using MA.DataSync.Core.Interfaces;

namespace MA.DataSync.Application.Orchestration;

/// <summary>
/// Orchestrates the entire sync process with streaming and checkpointing.
/// </summary>
public class SyncOrchestrator : ISyncOrchestrator
{
    private readonly IBigQueryExtractor _extractor;
    private readonly IBatchProcessor _batchProcessor;
    private readonly ICheckpointRepository _checkpointRepository;
    private readonly IDeadLetterRepository _deadLetterRepository;  
    private readonly EntityMappingsConfig _mappings;
    private readonly SyncSettings _settings;
    private readonly ILogger<SyncOrchestrator> _logger;

    private const int StreamBufferSize = 1000;

    public SyncOrchestrator(
        IBigQueryExtractor extractor,
        IBatchProcessor batchProcessor,
        ICheckpointRepository checkpointRepository,
        IDeadLetterRepository deadLetterRepository,  
        IOptions<EntityMappingsConfig> mappings,
        IOptions<SyncSettings> settings,
        ILogger<SyncOrchestrator> logger)
    {
        _extractor = extractor;
        _batchProcessor = batchProcessor;
        _checkpointRepository = checkpointRepository;
        _deadLetterRepository = deadLetterRepository;  
        _mappings = mappings.Value;
        _settings = settings.Value;
        _logger = logger;
    }

    public async Task<bool> RunAsync(CancellationToken cancellationToken = default)
    {
        var context = new SyncRunContext();
        var stopwatch = Stopwatch.StartNew();
        var lockAcquired = false;

        _logger.LogInformation("=== Starting Sync Run {RunId} ===", context.RunId);

        try
        {
            // Try to acquire lock
            lockAcquired = await _checkpointRepository.TryAcquireLockAsync(context.RunId, cancellationToken);

            if (!lockAcquired)
            {
                _logger.LogWarning("Another sync run is already in progress. Exiting.");
                return false;
            }

            // Process entities in order
            var entityOrder = new[] { EntityType.PhysicalPerson, EntityType.Contact, EntityType.Account };
            var allSuccess = true;

            foreach (var entityType in entityOrder)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    _logger.LogWarning("Cancellation requested. Stopping sync.");
                    break;
                }

                var mapping = GetMapping(entityType);
                if (string.IsNullOrEmpty(mapping.BigQueryTable))
                {
                    _logger.LogDebug("Skipping {EntityType} - not configured", entityType);
                    continue;
                }

                context.CurrentEntity = entityType;
                var success = await SyncEntityAsync(entityType, context, cancellationToken);

                if (!success)
                {
                    allSuccess = false;
                    _logger.LogWarning("{EntityType} sync completed with errors", entityType);
                }
            }

            // Complete the run
            stopwatch.Stop();
            context.CompletedAt = DateTime.UtcNow;
            context.Status = allSuccess ? SyncRunStatus.CompletedSuccess : SyncRunStatus.CompletedWithErrors;

            await _checkpointRepository.CompleteRunAsync(context.RunId, allSuccess, cancellationToken);

            _logger.LogInformation(
                "=== Sync Run {RunId} Completed in {Duration} ===",
                context.RunId, stopwatch.Elapsed);

            LogRunSummary(context);

            return allSuccess;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            context.Status = SyncRunStatus.Failed;
            _logger.LogError(ex, "Sync run {RunId} failed after {Duration}", context.RunId, stopwatch.Elapsed);
            return false;
        }
        finally
        {
            // Always release lock if we acquired it
            if (lockAcquired)
            {
                try
                {
                    await _checkpointRepository.ReleaseLockAsync(context.RunId, CancellationToken.None);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Failed to release lock for run {RunId}", context.RunId);
                }
            }
        }
    }

    public async Task<bool> RunForEntityAsync(
      EntityType entityType,
      CancellationToken cancellationToken = default)
    {
        var context = new SyncRunContext();
        context.CurrentEntity = entityType;
        var lockAcquired = false;

        _logger.LogInformation("=== Starting Single Entity Sync: {EntityType} (Run {RunId}) ===",
            entityType, context.RunId);

        try
        {
            lockAcquired = await _checkpointRepository.TryAcquireLockAsync(context.RunId, cancellationToken);

            if (!lockAcquired)
            {
                _logger.LogWarning("Another sync run is already in progress. Exiting.");
                return false;
            }

            var success = await SyncEntityAsync(entityType, context, cancellationToken);

            await _checkpointRepository.CompleteRunAsync(context.RunId, success, cancellationToken);

            return success;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Single entity sync failed for {EntityType}", entityType);
            return false;
        }
        finally
        {
            if (lockAcquired)
            {
                try
                {
                    await _checkpointRepository.ReleaseLockAsync(context.RunId, CancellationToken.None);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Failed to release lock for run {RunId}", context.RunId);
                }
            }
        }
    }

    private async Task<bool> SyncEntityAsync(EntityType entityType, SyncRunContext context, CancellationToken cancellationToken)
    {
        var stopwatch = Stopwatch.StartNew();
        var stats = new EntitySyncStats { EntityType = entityType };
        context.EntityStats[entityType] = stats;

        _logger.LogInformation("--- Starting sync for {EntityType} ---", entityType);

        try
        {
            // Get watermark (where to start from)
            var watermark = await _checkpointRepository.GetWatermarkAsync(entityType, cancellationToken);
            var startFrom = watermark ?? DateTime.MinValue;

            _logger.LogInformation("Watermark for {EntityType}: {Watermark}",
                entityType, watermark?.ToString("yyyy-MM-dd HH:mm:ss") ?? "None (full sync)");

            // Get count for progress logging
            var totalCount = await _extractor.GetDeltaCountAsync(entityType, startFrom, cancellationToken);
            _logger.LogInformation("Found {Count} records to process for {EntityType}", totalCount, entityType);

            if (totalCount == 0)
            {
                _logger.LogInformation("No records to sync for {EntityType}", entityType);
                return true;
            }

            // Stream and process in chunks
            var buffer = new List<SyncRecord>();
            var processedCount = 0;
            var maxWatermark = startFrom;

            await foreach (var record in _extractor.ExtractDeltaAsync(entityType, startFrom, cancellationToken))
            {
                if (cancellationToken.IsCancellationRequested)
                    break;

                buffer.Add(record);

                // Track max watermark for checkpoint
                if (record.SourceModifiedDate > maxWatermark)
                {
                    maxWatermark = record.SourceModifiedDate;
                }

                // Process when buffer is full
                if (buffer.Count >= StreamBufferSize)
                {
                    var result = await ProcessBufferAsync(entityType, buffer, context, cancellationToken);
                    UpdateStats(stats, result);

                    processedCount += buffer.Count;
                    _logger.LogInformation(
                        "Progress: {Processed}/{Total} ({Percent}%) for {EntityType}",
                        processedCount, totalCount, (processedCount * 100) / totalCount, entityType);

                    // Save checkpoint
                    await _checkpointRepository.SetWatermarkAsync(
                        entityType, maxWatermark, context.RunId, cancellationToken);

                    buffer.Clear();
                }
            }

            // Process remaining records
            if (buffer.Count > 0)
            {
                var result = await ProcessBufferAsync(entityType, buffer, context, cancellationToken);
                UpdateStats(stats, result);
                processedCount += buffer.Count;

                // Final checkpoint
                await _checkpointRepository.SetWatermarkAsync(
                    entityType, maxWatermark, context.RunId, cancellationToken);
            }

            stopwatch.Stop();
            stats.ProcessingTime = stopwatch.Elapsed;

            _logger.LogInformation(
                "--- Completed {EntityType}: {Created} created, {Updated} updated, {Failed} failed in {Duration} ---",
                entityType, stats.Created, stats.Updated, stats.Failed, stopwatch.Elapsed);

            return stats.Failed == 0;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Error syncing {EntityType}", entityType);
            return false;
        }
    }

    private async Task<BatchProcessingResult> ProcessBufferAsync(EntityType entityType, List<SyncRecord> buffer, SyncRunContext context, CancellationToken cancellationToken)
    {
        _logger.LogDebug("Processing buffer of {Count} records for {EntityType}", buffer.Count, entityType);

        var result = await _batchProcessor.ProcessAsync(entityType, buffer, context, cancellationToken);

        // Save failed records to DLQ
        await SaveFailedRecordsToDlqAsync(result, context, cancellationToken);

        return result;
    }

    private void UpdateStats(EntitySyncStats stats, BatchProcessingResult result)
    {
        stats.TotalExtracted += result.TotalProcessed;
        stats.Created += result.Created;
        stats.Updated += result.Updated;
        stats.Deleted += result.Deleted;
        stats.Skipped += result.Skipped;
        stats.Failed += result.Failed;
    }

    private EntityMappingConfig GetMapping(EntityType entityType)
    {
        return entityType switch
        {
            EntityType.PhysicalPerson => _mappings.PhysicalPerson,
            EntityType.Contact => _mappings.Contact,
            EntityType.Account => _mappings.Account,
            _ => throw new ArgumentOutOfRangeException(nameof(entityType))
        };
    }

    private async Task SaveFailedRecordsToDlqAsync(BatchProcessingResult result, SyncRunContext context, CancellationToken cancellationToken)
    {
        if (result.FailedRecords == null || result.FailedRecords.Count == 0)
            return;

        var dlqRecords = result.FailedRecords.Select(record => new DeadLetterRecord
        {
            RunId = context.RunId,
            EntityType = record.EntityType,
            Operation = record.Operation,
            AlternateKeys = record.AlternateKeys,
            SourceData = record.SourceData,
            ErrorMessage = record.ErrorMessage ?? "Unknown error",
            RetryAttempts = record.RetryCount,
            FailedAt = DateTime.UtcNow
        }).ToList();

        try
        {
            await _deadLetterRepository.WriteBatchAsync(dlqRecords, cancellationToken);
            _logger.LogWarning("Saved {Count} failed records to Dead-Letter Queue", dlqRecords.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to write to Dead-Letter Queue");
        }
    }

    private void LogRunSummary(SyncRunContext context)
    {
        _logger.LogInformation("=== Run Summary ===");

        foreach (var (entityType, stats) in context.EntityStats)
        {
            _logger.LogInformation(
                "{EntityType}: Extracted={Extracted}, Created={Created}, Updated={Updated}, Deleted={Deleted}, Failed={Failed}, Time={Time}",
                entityType,
                stats.TotalExtracted,
                stats.Created,
                stats.Updated,
                stats.Deleted,
                stats.Failed,
                stats.ProcessingTime);
        }
    }
}