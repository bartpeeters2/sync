﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using MA.DataSync.Application;
using MA.DataSync.Infrastructure;
using MA.DataSync.Core.Interfaces;
using Microsoft.Extensions.Configuration;

// Configure Serilog
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Debug()
    .WriteTo.Console(outputTemplate:
        "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}")
    .CreateLogger();

try
{
    Log.Information("=== MA.DataSync Starting ===");

    var host = Host.CreateDefaultBuilder(args)
        .UseSerilog()
        .ConfigureAppConfiguration((context, config) =>
        {
            config.SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false)
                .AddJsonFile($"appsettings.{context.HostingEnvironment.EnvironmentName}.json", optional: true)
                .AddUserSecrets<Program>(optional: true)
                .AddEnvironmentVariables();
        })
        .ConfigureServices((context, services) =>
        {
            // Register Infrastructure (BigQuery, Dataverse, etc.)
            services.AddInfrastructure(context.Configuration);

            // Register Application (Orchestrator, BatchProcessor, etc.)
            services.AddApplication();
        })
        .Build();

    // Run the orchestrator
    var orchestrator = host.Services.GetRequiredService<ISyncOrchestrator>();
    var success = await orchestrator.RunAsync();

    Log.Information("=== MA.DataSync Completed: {Status} ===", success ? "SUCCESS" : "WITH ERRORS");

    return success ? 0 : 1;
}
catch (Exception ex)
{
    Log.Fatal(ex, "MA.DataSync failed");
    return 1;
}
finally
{
    Log.CloseAndFlush();
}