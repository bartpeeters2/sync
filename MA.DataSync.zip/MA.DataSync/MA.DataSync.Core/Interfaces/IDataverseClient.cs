﻿using MA.DataSync.Core.Entities;
using MA.DataSync.Core.Enums;

namespace MA.DataSync.Core.Interfaces;

/// <summary>
/// Client for interacting with Microsoft Dataverse.
/// Handles existence checks and CRUD operations.
/// </summary>
public interface IDataverseClient
{
    /// <summary>
    /// Checks which records already exist in Dataverse (bulk operation).
    /// Returns the Dataverse ID for existing records.
    /// </summary>
    /// <param name="entityType">The entity type to check.</param>
    /// <param name="records">Records to check for existence.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>
    /// Dictionary mapping alternate key (e.g., email) to Dataverse GUID.
    /// Records not in dictionary don't exist in Dataverse.
    /// </returns>
    Task<Dictionary<string, Guid>> CheckExistenceAsync(
        EntityType entityType,
        IEnumerable<SyncRecord> records,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Creates multiple records in Dataverse (bulk operation).
    /// </summary>
    /// <param name="entityType">The entity type to create.</param>
    /// <param name="records">Records to create.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>Results for each record (success/failure with details).</returns>
    Task<IEnumerable<SyncRecordResult>> CreateAsync(
        EntityType entityType,
        IEnumerable<SyncRecord> records,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Updates multiple records in Dataverse (bulk operation).
    /// </summary>
    /// <param name="entityType">The entity type to update.</param>
    /// <param name="records">Records to update (must have DataverseId set).</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>Results for each record (success/failure with details).</returns>
    Task<IEnumerable<SyncRecordResult>> UpdateAsync(
        EntityType entityType,
        IEnumerable<SyncRecord> records,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Deactivates multiple records in Dataverse (soft delete).
    /// Sets statecode = 1 (inactive).
    /// </summary>
    /// <param name="entityType">The entity type to deactivate.</param>
    /// <param name="records">Records to deactivate (must have DataverseId set).</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>Results for each record (success/failure with details).</returns>
    Task<IEnumerable<SyncRecordResult>> DeactivateAsync(
        EntityType entityType,
        IEnumerable<SyncRecord> records,
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Result of a sync operation for a single record.
/// </summary>
public class SyncRecordResult
{
    /// <summary>
    /// The record that was processed.
    /// </summary>
    public required SyncRecord Record { get; set; }

    /// <summary>
    /// Was the operation successful?
    /// </summary>
    public bool Success { get; set; }

    /// <summary>
    /// The Dataverse ID (set after successful create).
    /// </summary>
    public Guid? DataverseId { get; set; }

    /// <summary>
    /// Error message if failed.
    /// </summary>
    public string? ErrorMessage { get; set; }

    /// <summary>
    /// Dataverse error code if failed.
    /// </summary>
    public string? ErrorCode { get; set; }

    /// <summary>
    /// Is this a transient error (retry) or permanent (DLQ)?
    /// </summary>
    public bool IsTransient { get; set; }
}
