﻿using Google.Cloud.SecretManager.V1;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MA.DataSync.Core.Configuration;
using MA.DataSync.Core.Interfaces;

namespace MA.DataSync.Infrastructure.Secrets;

/// <summary>
/// Retrieves secrets from Google Cloud Secret Manager.
/// Used in production (Cloud Run). Falls back to local config in development.
/// </summary>
public class SecretManagerService : ISecretManager
{
    private readonly SecretManagerServiceClient? _client;
    private readonly string _projectId;
    private readonly ServicePrincipalSettings _spSettings;
    private readonly ILogger<SecretManagerService> _logger;
    private readonly bool _isEnabled;

    public SecretManagerService(
        IOptions<BigQuerySettings> bqSettings,
        IOptions<ServicePrincipalSettings> spSettings,
        ILogger<SecretManagerService> logger)
    {
        _projectId = bqSettings.Value.ProjectId;
        _spSettings = spSettings.Value;
        _logger = logger;

        // Only enable in production (when no local key file is configured)
        _isEnabled = string.IsNullOrEmpty(bqSettings.Value.ServiceAccountKeyPath);

        if (_isEnabled)
        {
            try
            {
                _client = SecretManagerServiceClient.Create();
                _logger.LogInformation("Secret Manager enabled for project: {ProjectId}", _projectId);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to create Secret Manager client. Secrets will not be available.");
                _isEnabled = false;
            }
        }
        else
        {
            _logger.LogDebug("Secret Manager disabled (using local configuration)");
        }
    }

    public async Task<string> GetSecretAsync(
        string secretName,
        CancellationToken cancellationToken = default)
    {
        if (!_isEnabled || _client == null)
        {
            throw new InvalidOperationException(
                $"Secret Manager is not enabled. Cannot retrieve secret: {secretName}");
        }

        try
        {
            var secretVersionName = new SecretVersionName(_projectId, secretName, "latest");
            var response = await _client.AccessSecretVersionAsync(secretVersionName, cancellationToken);
            var secret = response.Payload.Data.ToStringUtf8();

            _logger.LogDebug("Retrieved secret: {SecretName}", secretName);
            return secret;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to retrieve secret: {SecretName}", secretName);
            throw;
        }
    }

    public async Task<string?> GetSecretOrDefaultAsync(
        string secretName,
        CancellationToken cancellationToken = default)
    {
        if (!_isEnabled || _client == null)
        {
            _logger.LogDebug("Secret Manager not enabled, returning null for: {SecretName}", secretName);
            return null;
        }

        try
        {
            return await GetSecretAsync(secretName, cancellationToken);
        }
        catch
        {
            _logger.LogDebug("Secret not found, returning null for: {SecretName}", secretName);
            return null;
        }
    }

    public async Task<IReadOnlyList<ServicePrincipalCredentials>> GetServicePrincipalsAsync(
        CancellationToken cancellationToken = default)
    {
        var credentials = new List<ServicePrincipalCredentials>();

        if (!_isEnabled || _client == null)
        {
            _logger.LogDebug("Secret Manager not enabled, no Service Principals from secrets");
            return credentials;
        }

        var prefix = _spSettings.SecretNamePrefix;
        var maxSPs = _spSettings.MaxServicePrincipals;

        for (int i = 1; i <= maxSPs; i++)
        {
            try
            {
                var tenantId = await GetSecretOrDefaultAsync($"{prefix}{i}-tenant-id", cancellationToken);
                var clientId = await GetSecretOrDefaultAsync($"{prefix}{i}-client-id", cancellationToken);
                var clientSecret = await GetSecretOrDefaultAsync($"{prefix}{i}-client-secret", cancellationToken);

                if (!string.IsNullOrEmpty(tenantId) &&
                    !string.IsNullOrEmpty(clientId) &&
                    !string.IsNullOrEmpty(clientSecret))
                {
                    credentials.Add(new ServicePrincipalCredentials
                    {
                        Id = $"SP{i}",
                        TenantId = tenantId,
                        ClientId = clientId,
                        ClientSecret = clientSecret
                    });

                    _logger.LogInformation("Loaded Service Principal {Id} from Secret Manager", $"SP{i}");
                }
                else
                {
                    _logger.LogDebug("Service Principal {Index} not fully configured in Secret Manager", i);
                    break; // Stop if one is not configured
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to load Service Principal {Index}", i);
                break;
            }
        }

        _logger.LogInformation("Loaded {Count} Service Principal(s) from Secret Manager", credentials.Count);
        return credentials;
    }
}