﻿namespace MA.DataSync.Core.Interfaces;

/// <summary>
/// Retrieves secrets from Google Cloud Secret Manager.
/// Used for Service Principal credentials.
/// </summary>
public interface ISecretManager
{
    /// <summary>
    /// Gets a secret value by name.
    /// </summary>
    /// <param name="secretName">The name of the secret in Secret Manager.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The secret value.</returns>
    Task<string> GetSecretAsync(
        string secretName,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets a secret value, returning null if not found.
    /// </summary>
    /// <param name="secretName">The name of the secret.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The secret value, or null if not found.</returns>
    Task<string?> GetSecretOrDefaultAsync(
        string secretName,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets all Service Principal credentials.
    /// Supports multiple SPs for multiplexing.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>List of SP credentials.</returns>
    Task<IReadOnlyList<ServicePrincipalCredentials>> GetServicePrincipalsAsync(
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Credentials for a Dataverse Service Principal.
/// </summary>
public class ServicePrincipalCredentials
{
    /// <summary>
    /// Identifier for this SP (for logging, e.g., "SP1", "SP2").
    /// </summary>
    public string Id { get; set; } = string.Empty;

    /// <summary>
    /// Azure AD Tenant ID.
    /// </summary>
    public string TenantId { get; set; } = string.Empty;

    /// <summary>
    /// Application (Client) ID.
    /// </summary>
    public string ClientId { get; set; } = string.Empty;

    /// <summary>
    /// Client Secret.
    /// </summary>
    public string ClientSecret { get; set; } = string.Empty;
}
