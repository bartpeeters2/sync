﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MA.DataSync.Core.Configuration;
using MA.DataSync.Core.Interfaces;
using MA.DataSync.Infrastructure.BigQuery;
using MA.DataSync.Infrastructure.Dataverse;
using MA.DataSync.Infrastructure.Secrets;

namespace MA.DataSync.Infrastructure;

/// <summary>
/// Registers Infrastructure services with dependency injection.
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Register configuration
        services.Configure<BigQuerySettings>(configuration.GetSection("BigQuery"));
        services.Configure<DataverseSettings>(configuration.GetSection("Dataverse"));
        services.Configure<EntityMappingsConfig>(configuration.GetSection("EntityMappings"));
        services.Configure<LocalServicePrincipalSettings>(configuration.GetSection("ServicePrincipal"));
        services.Configure<ServicePrincipalSettings>(configuration.GetSection("ServicePrincipals"));
        services.Configure<SyncSettings>(configuration.GetSection("Sync"));

        // Register services
        services.AddSingleton<IBigQueryExtractor, BigQueryExtractor>();
        services.AddSingleton<IDataverseClient, DataverseClient>();
        services.AddSingleton<ICheckpointRepository, CheckpointRepository>();
        services.AddSingleton<IDeadLetterRepository, DeadLetterRepository>();
        services.AddSingleton<ISecretManager, SecretManagerService>();

        return services;
    }
}