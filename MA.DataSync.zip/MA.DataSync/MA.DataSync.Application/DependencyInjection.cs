﻿using Microsoft.Extensions.DependencyInjection;
using MA.DataSync.Core.Interfaces;
using MA.DataSync.Application.Pipeline;
using MA.DataSync.Application.Orchestration;
using MA.DataSync.Application.Resilience;

namespace MA.DataSync.Application;

/// <summary>
/// Registers Application services with dependency injection.
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        // Pipeline
        services.AddSingleton<IBatchProcessor, BatchProcessor>();
        // Orchestration
        services.AddSingleton<ISyncOrchestrator, SyncOrchestrator>();

        // Resilience
        services.AddSingleton<RetryPolicyService>();

        // We'll register these as we build them:
        // - IThrottleController
        // - IEntityMapper

        return services;
    }
}